<?php

return [
    'registration_complete' => 'Your account has been successfully registered Please verify your email address.',
    'login_success' => 'Login Success.',
    'email_not_verfied' => 'Please verify your email before proceeding.',
    'email_verified' => 'Your email has been successfully verified.',
    'email_already_verified' => 'Email already verified.',
    'email_exists' => 'Email already exists.',
    'account_blocked' => 'Your account has been blocked, please contact the admin.',
    'user_not_found' => 'User not found.',
    'user_info' => 'User Details.',
    'user_update' => 'Your account has been successfully updated.',
    'user_update_status' => 'User status has been successfully updated.',
    'token_invalid' => 'Unauthorized.',
    'token_absent' => 'Authorization not found.',
    'invalid_credentials' => 'Invalid credentials',
    'phone_exists' => 'Phone number already exists',
    'invalid_country' => "Invalid country"
];
