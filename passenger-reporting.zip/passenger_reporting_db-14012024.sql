-- MySQL dump 10.13  Distrib 8.0.40, for Linux (x86_64)
--
-- Host: localhost    Database: passenger_reporting_db
-- ------------------------------------------------------
-- Server version	8.0.40-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `destinations`
--

DROP TABLE IF EXISTS `destinations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `destinations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(512) DEFAULT NULL,
  `short_name` varchar(512) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `address` varchar(1024) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `updated_name` varchar(512) DEFAULT NULL,
  `stop_id` varchar(100) DEFAULT NULL,
  `legacy_position` varchar(100) DEFAULT NULL,
  `uuid` char(36) DEFAULT NULL,
  `platform_number` int DEFAULT NULL,
  `source` enum('API','Custom') DEFAULT 'API',
  `departure_time` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bus_stops_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destinations`
--

LOCK TABLES `destinations` WRITE;
/*!40000 ALTER TABLE `destinations` DISABLE KEYS */;
INSERT INTO `destinations` VALUES (1,'Charleroi Airport (CRL)','Charleroi Airport (CRL)','The shuttle bus terminal is located at the front of the exit of the Terminal 1.','Brussels South Charleroi Airport - Shuttle bus terminal (in front of terminal 1)','2024-09-19 23:34:05','2024-10-07 09:01:04','active','Charleroi Airport (CRL)','15','1','8f5f5e6a-76b1-11ef-8f56-00090ffe0001',11,'API',''),(2,'Brussels Midi Station','Brussels Midi Station','Brussels Gare de Midi','Gare du Midi Zuidstation (Rue de France)','2024-09-19 23:34:05','2024-10-10 11:39:00','active','Brussels Midi Station','63','2','8f5febe9-76b1-11ef-8f56-00090ffe0001',9,'API',''),(3,'Ghent','Ghent','The bus stop is located at 3 Voskenslaan, perron 22/23.','Sint Pietersstation 3 Voskenslaan perron 22/23','2024-09-19 23:34:05','2024-10-10 13:14:25','active','Ghent','72','2','8f60900c-76b1-11ef-8f56-00090ffe0001',10,'API',NULL),(4,'Bruges','Bruges','The bus stop is located behind the train station at  the corner with Rijselstraat and Spoorwegstraat on the kiss & ride zone.','Station (Rijselstraat-Spoorwegstraat / kiss & ride zone)','2024-09-19 23:34:05','2024-10-10 13:11:34','active','Gent - Bruges','73','3','8f6103bc-76b1-11ef-8f56-00090ffe0001',6,'API',NULL),(5,'Liege','Liege','The stop is located at Rue du Plan InclinÃ© in front of the Hotel-Brasserie Univers.','LiÃ¨ge Guillemins station (Rue du Plan InclinÃ© in front of the Hotel-Brasserie Univers)','2024-09-19 23:34:05',NULL,'active','Liege','319','2','8f61d773-76b1-11ef-8f56-00090ffe0001',5,'API',NULL),(6,'Maastricht','Maastricht','The bus station is located at the backside of the railway station. Access via a ramp/bridge which is crossing over the railways.','International bus station, Meerssenerweg 259','2024-09-19 23:34:05',NULL,'active','Maastricht','320','3','8f6248bc-76b1-11ef-8f56-00090ffe0001',5,'API',NULL),(7,'Brussels Airport Zaventem (BRU)','Brussels Airport Zaventem (BRU)','Brussels Airport Zaventem at the parking P16','Brussels Airport Zaventem - Intercity bus parking P16','2024-09-19 23:34:05',NULL,'active','Brussels Airport Zaventem (BRU)','1012','2','8f62ec35-76b1-11ef-8f56-00090ffe0001',2,'API',NULL),(8,'Antwerp','Antwerp','The stop is located at bay B5 on the Franklin Rooseveltsquare (Franklin Roosveltplaats)','Franklin Rooseveltplaats - 2060 Antwerpen (BE)','2024-09-19 23:34:05',NULL,'active','Antwerp','1028','3','8f6360a3-76b1-11ef-8f56-00090ffe0001',2,'API',NULL),(9,'Breda','Breda','The stop is located at the International Bus Station near the north side exit of Breda Central station.','Stationslaan 4815 CG Breda (NL)','2024-09-19 23:34:05','2024-10-10 11:36:14','active','Anvers - Breda','1029','4','8f63c838-76b1-11ef-8f56-00090ffe0001',2,'API',NULL),(10,'Arlon','Arlon','The bus stop is located at 202, Route de NeufchÃ¢teau, at the gas station ESSO.','Route de Neufchateau 202 (at the ESSO petrol station)','2024-09-19 23:34:05',NULL,'active','Arlon','52','2','8f648b0c-76b1-11ef-8f56-00090ffe0001',7,'API',NULL),(11,'Luxembourg Bouillon','Luxembourg Bouillon','The bus stop is located on the bus park from P+R Bouillon. When leaving the car park, turn left on the pavement, the bus stop will be approx. 15 m after the end of the pavement.\r\nBy car: take the motorway A1 (Trier-Luxembourg-Arlon), take the exit Croix de Cessange towards Hollerich/ Luxembourg/ P+R Bouillon.\r\n','P+R Bouillon (bus parking)','2024-09-19 23:34:05',NULL,'active','Arlon - Luxembourg','12','3','8f650388-76b1-11ef-8f56-00090ffe0001',7,'API',NULL),(12,'Mons','Mons','Avenue Meline Mercouri at the front of the Van Der Valk Mons hotel.','Avenue Meline Mercouri at the front of the Van Der Valk Mons hotel.','2024-09-19 23:34:05',NULL,'active','Mons','80','2','8f65a6ea-76b1-11ef-8f56-00090ffe0001',8,'API',NULL),(13,'Lille â€“ Lille Europe','Lille â€“ Lille Europe','The bus stop is located next to the Lille Europe train station, on the Boulevard de Turin opposite the \"Novotel suite\" hotel.','Gare de Lille Europe (boulevard de Turin)','2024-09-19 23:34:05',NULL,'active','Mons - Lille','54','3','8f6604ec-76b1-11ef-8f56-00090ffe0001',8,'API',NULL),(14,'Kortrijk via Lille','Kortrijk via Lille','','','2024-09-20 09:09:55','2024-09-20 09:09:55','active','Kortrijk via Lille',NULL,NULL,'1a7dc24d-7730-11ef-8674-00090ffe0001',8,'Custom','08:00'),(15,'Kortrijk via Lille','Kortrijk via Lille','','','2024-09-20 09:12:15','2024-09-20 09:12:15','active','Kortrijk via Lille',NULL,NULL,'6dbe2a41-7730-11ef-8674-00090ffe0001',8,'Custom','11:00'),(16,'Kortrijk via Lille','Kortrijk via Lille','','','2024-09-20 09:12:15','2024-10-10 13:12:09','active','Kortrijk via Lille',NULL,NULL,'80d984f5-7730-11ef-8674-00090ffe0001',8,'Custom','12:30'),(17,'Kortrijk via Lille','Kortrijk via Lille','','','2024-09-20 09:12:15','2024-09-20 09:12:15','active','Kortrijk via Lille',NULL,NULL,'a286a10f-7730-11ef-8674-00090ffe0001',8,'Custom','14:00'),(18,'Kortrijk via Lille','Kortrijk via Lille','','','2024-09-20 09:12:15','2024-09-20 09:12:15','active','Kortrijk via Lille',NULL,NULL,'a286a75e-7730-11ef-8674-00090ffe0001',8,'Custom','15:30'),(19,'Kortrijk via Lille','Kortrijk via Lille','','','2024-09-20 09:12:15','2024-09-20 09:12:15','active','Kortrijk via Lille',NULL,NULL,'a286a7c7-7730-11ef-8674-00090ffe0001',8,'Custom','18:30'),(20,'Kortrijk via Lille','Kortrijk via Lille','','','2024-09-20 09:12:15','2024-09-20 09:12:15','active','Kortrijk via Lille',NULL,NULL,'a286a8aa-7730-11ef-8674-00090ffe0001',8,'Custom','21:30'),(21,'Kortrijk via Lille','Kortrijk via Lille','','','2024-09-20 09:12:15','2024-09-20 09:12:15','active','Kortrijk via Lille',NULL,NULL,'a286a8ff-7730-11ef-8674-00090ffe0001',8,'Custom','23:15'),(22,'P3','P3','','','2024-09-20 09:15:09','2024-09-20 09:15:09','active','P3',NULL,NULL,'d582254a-7730-11ef-8674-00090ffe0001',11,'Custom',NULL),(23,'DOOR 2 GATE','DOOR 2 GATE','','','2024-09-20 09:15:43','2024-09-20 09:15:43','active','DOOR 2 GATE',NULL,NULL,'e9ce540d-7730-11ef-8674-00090ffe0001',3,'Custom',NULL);
/*!40000 ALTER TABLE `destinations` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `insertDestinationUniqueUUID` BEFORE INSERT ON `destinations` FOR EACH ROW BEGIN
	SET NEW.uuid = generate_uuid();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` char(36) DEFAULT NULL,
  `message` text,
  `start_datetime` timestamp NULL DEFAULT NULL,
  `end_datetime` timestamp NULL DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `service_status` enum('active','inactive') DEFAULT 'inactive',
  `when_service_active` timestamp NULL DEFAULT NULL,
  `when_apply` enum('now','datetime') DEFAULT 'now',
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'ed700098-7724-11ef-8674-00090ffe0001','The vehicle with licence plate ME6300 needs to move his vehicle now!','2024-10-02 00:00:00','2024-10-31 00:00:00','inactive','2024-09-20 13:19:55','2024-10-10 13:20:21','inactive','2024-10-07 08:31:41','now');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `insertSettingUniqueUUID` BEFORE INSERT ON `settings` FOR EACH ROW BEGIN
	SET NEW.uuid = generate_uuid();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `user_type` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_email_verified` tinyint(1) NOT NULL DEFAULT '1',
  `email_verify_token` varchar(1024) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `password_reset_token` varchar(1024) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_UN` (`email`),
  UNIQUE KEY `users_uuid_UN` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,'5c61ce57-74cc-11ef-8bde-f446374c7c55','info@encoresky.com','Admin','$2y$12$MrSz3J//Fd2sucjzpRkJbu5zdjhbj9KockjARHy25oDLhWf3IAzvy','Admin',1,1,NULL,'2024-09-17 08:10:54',NULL,NULL,0,NULL,'2024-09-17 08:10:54','2024-09-17 05:17:48',NULL),(4,'a84bc331-76b7-11ef-8f56-00090ffe0001','fc.patidar@encoresky.com','FC Patidar','$2y$12$MrSz3J//Fd2sucjzpRkJbu5zdjhbj9KockjARHy25oDLhWf3IAzvy','SubAdmin',1,1,NULL,NULL,NULL,NULL,0,NULL,'2024-09-19 18:47:44','2024-09-20 10:30:29',NULL),(5,'fe6ad8ca-8091-11ef-9c81-bc2411dab25b','simon.livesey@icon.lu','Simon Livesey','$2y$12$k8q157F4Zh8UbcTrcB54eO/fga5mYKDMj6dnmGgSIMBNGD5ckwKxi','SubAdmin',1,1,NULL,NULL,NULL,NULL,0,NULL,'2024-10-02 07:43:19','2024-10-03 07:42:53',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `insertUserUniqueUUID` BEFORE INSERT ON `users` FOR EACH ROW BEGIN
	SET NEW.uuid = generate_uuid();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-14 11:29:49
