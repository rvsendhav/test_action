<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\UserProvider::class,
    App\Providers\VehicleStopProvider::class,
    App\Providers\VehicleSettingProvider::class,
    App\Providers\PassengerLogProvider::class,
    App\Providers\EventServiceProvider::class,
];
