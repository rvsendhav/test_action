<?php

if (!function_exists('filterInputData')) {
    function filterInputData($input)
    {
        return array_filter($input, function ($key) {
            return $key !== '_token';
        }, ARRAY_FILTER_USE_KEY);
    }
}
