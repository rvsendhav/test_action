<?php
require_once __DIR__ . '/Helpers.php';

use App\Exceptions\CustomException;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Illuminate\Foundation\Configuration\Middleware;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Tymon\JWTAuth\Exceptions\JWTException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        api: __DIR__ . '/../routes/api.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'web' => [
                \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
                \Illuminate\Session\Middleware\StartSession::class,
                \Illuminate\View\Middleware\ShareErrorsFromSession::class,
                \Illuminate\Routing\Middleware\SubstituteBindings::class,
                \App\Http\Middleware\SetLocale::class,
            ],
            'api' => [
                'throttle:api',
                \Illuminate\Routing\Middleware\SubstituteBindings::class,
                \App\Http\Middleware\Api\SetLocaleApi::class,
                \App\Http\Middleware\Api\CheckHeaders::class,
            ],
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        $exceptions->renderable(function (Throwable $e, Request $request) {
            // Check if the request expects JSON (API handling)
            if ($request->expectsJson()) {
                if ($e instanceof CustomException) {
                    return response()->json([
                        'success' => false,
                        'message' => $e->getMessage(),
                        'data' => $e->getData(),
                    ], 400);
                } elseif ($e instanceof NotFoundHttpException) {
                    \Log::error($e->getMessage());
                    return response()->json([
                        'success' => false,
                        'message' => __("messages.resource_not_found"),
                        'error' => __("messages.resource_not_found")
                    ], 404);
                } elseif ($e instanceof ValidationException) {
                    return response()->json([
                        'success' => false,
                        'message' => $e->validator->errors()->first(),
                        'errors' => $e->validator->errors(),
                    ], 422);
                } elseif ($e instanceof AuthenticationException) {
                    return response()->json([
                        'success' => false, 
                        'message' => __("messages.auth_required"), 
                        'error' => __("messages.auth_required")], 
                    401);
                } elseif ($e instanceof AuthorizationException) {
                    return response()->json([
                        'success' => false, 
                        'message' => __("messages.not_authorized"), 
                        'error' => __("messages.not_authorized")], 
                    403);
                } elseif ($e instanceof HttpException) {
                    \Log::error($e->getMessage());
                    return response()->json([
                        'success' => false, 
                        'message' => $e->getMessage(), 
                        'error' => $e->getMessage()], 
                    $e->getStatusCode());
                } elseif ( $e instanceof TokenExpiredException ) {
                    // Token has expired
                    return response()->json([
                        'success' => false, 
                        'message' => __("messages.token_expired"), 
                        'error' => __("messages.token_expired")
                    ], 401);
                } elseif ( $e instanceof TokenInvalidException ) {
                    // Token is invalid
                    return response()->json([
                        'success' => false, 
                        'message' => __("messages.token_invalid"), 
                        'error' => __("messages.token_invalid")
                    ], 401);
                } elseif ($e instanceof JWTException ) {
                    // Token is missing or another JWT-related error occurred
                    return response()->json([
                        'success' => false, 
                        'message' => __("messages.token_absent"), 
                        'error' => __("messages.token_absent")
                ], 401);
                } else {
                    \Log::error($e->getMessage());
                    return response()->json([
                        'success' => false, 
                        'message' => __("messages.something_went_wrong"), 
                        'error' => __("messages.something_went_wrong")], 
                    500);
                }
            } else {
                // Handle web requests
                if ($e instanceof CustomException) {
                    $data = $e->getData();
                    $route = $e->getRoute();
                    if ($route) {
                        if ($e->getMessage()) {
                            session()->flash('error', $e->getMessage());
                        }
                        return redirect()->route($route)->with($data);
                    } else {
                        session()->flash('error', $e->getMessage());
                        return redirect()->back()->withInput(filterInputData(request()->all()))->with($data);
                    }
                } elseif ($e instanceof NotFoundHttpException) {
                    return redirect()->route('web.page_not_found')->with([]);
                } elseif ($e instanceof ValidationException) {
                    $error = $e->validator->errors()->first();
                    session()->flash('error', $error);
                    return redirect()->back()->withErrors($e->validator)->withInput(filterInputData(request()->all()));
                } elseif ($e instanceof AuthenticationException) {
                    session()->flash('error', __("messages.auth_required"));
                    return redirect()->route('index')->with([]);
                } elseif ($e instanceof AuthorizationException) {
                    session()->flash('error', __("messages.not_authorized"));
                    return redirect()->route('index')->with([]);
                } elseif ($e instanceof HttpException) {
                    \Log::error($e->getMessage());
                    session()->flash('error', $e->getMessage());
                    return redirect()->back()->with([])->withInput(filterInputData(request()->all()));
                } else {
                    \Log::error($e->getMessage());
                    session()->flash('error', __("messages.something_went_wrong"));
                    return redirect()->back()->with([])->withInput(filterInputData(request()->all()));
                }
            }
        });
    })->create();
