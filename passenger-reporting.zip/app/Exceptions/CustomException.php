<?php

namespace App\Exceptions;

use Exception;

class CustomException extends Exception
{
    protected $message;
    protected $statusCode;

    public function __construct($message = "Something went wrong!", $statusCode = 400, $data = null, $route = "")
    {
        parent::__construct($message);
        $this->message = $message;
        $this->statusCode = $statusCode;
        $this->data = $data;
        $this->route = $route;
    }

    public function getStatusCode()
    {
        return $this->statusCode;
    }

    public function getData()
    {
        return $this->data;
    }

    public function getRoute()
    {
        return $this->route;
    }
}
