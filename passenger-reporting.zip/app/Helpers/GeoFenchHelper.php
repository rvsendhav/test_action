<?php

namespace App\Helpers;

class GeoFenchHelper
{
    /**
     * Generate GeoFences for given stops.
     * @param \Illuminate\Support\Collection $stops
     * @return array
     */
    public static function generateGeoFences($stops)
    {
        // Step 1: Create initial geofences with a 200m radius
        $geoFences = $stops->map(function ($stop) {
            return [
                'id' => $stop->id,
                'latitude' => (double) $stop->latitude,
                'longitude' => (double) $stop->longitude,
                'radius' => 200, // Start with 200m
            ];
        });

        // Step 2: Adjust for non-overlapping and minimum distance
        $geoFences = $geoFences->map(function ($geoFence, $index) use ($geoFences) {
            foreach ($geoFences as $j => $otherGeoFence) {
                if ($index >= $j) {
                    continue; // Avoid redundant comparisons
                }

                // Calculate the distance between two geo-fences
                $distance = self::calculateDistance(
                    $geoFence['latitude'], $geoFence['longitude'],
                    $otherGeoFence['latitude'], $otherGeoFence['longitude']
                );

                // Adjust radius if distance is less than 250m
                if ($distance < 250) {
                    $geoFence['radius'] = min($geoFence['radius'], $distance / 2 - 25);
                }
            }
            return $geoFence;
        });

        return $geoFences->values()->all(); // Convert back to a pure array if needed
    }

    /**
     * Find the nearest stop from the given geofences.
     * @param float $latitude
     * @param float $longitude
     * @param \Illuminate\Support\Collection|array $geoFences
     * @return array|null
     */
    public static function findNearestStop($latitude, $longitude, $geoFences)
    {
        // Ensure geoFences is a collection
        $geoFences = collect($geoFences);

        // Step 1: Check if there is a geo fence within the 200m radius
        $matchingGeoFence = $geoFences->first(function ($geoFence) use ($latitude, $longitude) {
            $distance = self::calculateDistance($latitude, $longitude, $geoFence['latitude'], $geoFence['longitude']);
            return $distance <= $geoFence['radius'];
        });

        // Step 2: If no matching geo fence is found, find the nearest geo fence
        if (!$matchingGeoFence) {
            $nearestGeoFence = $geoFences->reduce(function ($nearest, $geoFence) use ($latitude, $longitude) {
                $distance = self::calculateDistance($latitude, $longitude, $geoFence['latitude'], $geoFence['longitude']);
                if (!$nearest || $distance < $nearest['distance']) {
                    $geoFence['distance'] = $distance; // Store the distance for comparison
                    return $geoFence;
                }
                return $nearest;
            });

            return $nearestGeoFence;
        } else {
            return $matchingGeoFence;
        }
    }

    /**
     * Find a vehicle's ID by vehicle number.
     * @param \Illuminate\Support\Collection $vehicles
     * @param string $vehicleNumber
     * @return int|null
     */
    public static function findVehicleId($vehicles, $vehicleNumber)
    {
        $vehicle = $vehicles->first(function ($vehicle) use ($vehicleNumber) {
            return $vehicle->name === $vehicleNumber;
        });

        return $vehicle ? $vehicle->id : null;
    }

    /**
     * Calculate the distance between two coordinates using Haversine formula.
     * @param float $lat1
     * @param float $lon1
     * @param float $lat2
     * @param float $lon2
     * @return float Distance in meters
     */
    public static function calculateDistance($lat1, $lon1, $lat2, $lon2)
    {
        $earthRadius = 6371000; // meters
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);
        $a = sin($dLat / 2) * sin($dLat / 2) +
        cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
        sin($dLon / 2) * sin($dLon / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        return $earthRadius * $c;
    }
}
