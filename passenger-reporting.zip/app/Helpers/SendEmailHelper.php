<?php

namespace App\Helpers;

use App\Mail\SendEmailNotification;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class SendEmailHelper
{
    public static function sendEmail($payload)
    {
        try {
            Log::info("TRIGGER EMAIL HELPER");

            $template = $payload["template"];
            $to_email = $payload["to_email"];
            $subject = $payload["subject"];
            $to_name = $payload["to_name"];
            $email_data = $payload["email_data"];

            $mail = Mail::to($to_email, $to_name);
            $message = new SendEmailNotification($template, $email_data, $subject);
            $mail->send($message);
           
        } catch (\Exception $ex) {
            Log::error($ex->getMessage());
        }
    }
}
