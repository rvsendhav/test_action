<?php

namespace App\Helpers;

class CustomHelper
{
    public static function userType($user_type) {
        $list = [
            'ADMIN' => "Admin",
            'SUBADMIN' => "SubAdmin"
        ];
        return $list[$user_type];
    }
}
