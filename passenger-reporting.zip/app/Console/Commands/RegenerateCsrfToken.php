<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Session;

class RegenerateCsrfToken extends Command
{
    protected $signature = 'csrf:regenerate';
    protected $description = 'Regenerate the CSRF token';

    public function handle()
    {
        // Regenerate CSRF token
        Session::regenerateToken();

        $this->info('CSRF token regenerated successfully.');
    }
}
