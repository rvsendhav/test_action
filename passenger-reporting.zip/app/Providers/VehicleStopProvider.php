<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class VehicleStopProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register()
    {
        $this->app->bind('App\Repositories\VehicleStop\VehicleStopInterface', 
        'App\Repositories\VehicleStop\VehicleStopRepository');
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        //
    }
}
