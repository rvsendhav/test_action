<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class VehicleSettingProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register()
    {
        $this->app->bind('App\Repositories\VehicleSetting\VehicleSettingInterface', 
        'App\Repositories\VehicleSetting\VehicleSettingRepository');
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        //
    }
}
