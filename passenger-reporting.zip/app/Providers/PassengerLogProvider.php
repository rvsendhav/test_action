<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class PassengerLogProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register()
    {
        $this->app->bind('App\Repositories\PassengerLog\PassengerLogInterface', 
        'App\Repositories\PassengerLog\PassengerLogRepository');
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        //
    }
}
