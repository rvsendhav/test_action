<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class PassengerLog extends Model
{
    protected $fillable = [
        'stop_id',
        'vehicle_id',
        'log_date',
        'direction',
        'latitude',
        'longitude',
        'created_at',
        'updated_at',
    ];

    public $incrementing = false; // Since 'id' is not auto-incrementing
    protected $keyType = 'string'; // 'id' is a UUID (CHAR(36))


    public $table = 'passenger_logs';

    public function stop()
    {
        return $this->belongsTo(VehicleStop::class, 'stop_id');
    }

    public function vehicle()
    {
        return $this->belongsTo(VehicleSetting::class, 'vehicle_id');
    }

    /**
     * Choose a day of the month and display all stops and all ins and outs of that day of the month per stop.
     */
    public function getDayTotalInsOuts($day)
    {
            $logs = self::whereDate('log_date', $day)
                ->groupBy('stop_id')
                ->select(
                    DB::raw('stop_id as stop_id'),
                    DB::raw("COUNT(CASE WHEN direction = 'IN' THEN 1 ELSE NULL END) as total_in"),
                    DB::raw("COUNT(CASE WHEN direction = 'OUT' THEN 1 ELSE NULL END) as total_out")
                )
                ->get();
    
            $stopNames = VehicleStop::whereIn('id', $logs->pluck('stop_id'))->pluck('name', 'id');
    
            $logs->map(function ($log) use ($stopNames) {
                $log->label = $stopNames[$log->stop_id] ?? null;
                return $log;
            });
    
            return $logs;
    }

    /**
     * Choose a day of the month and show ins and outs per hour over that day.
     */
    public function getDayHourlyInsOuts($day)
    {
        return self::whereDate('log_date', $day)
            ->groupBy(DB::raw('DATE_FORMAT(log_date, "%H:00")'))
            ->orderBy(DB::raw('DATE_FORMAT(log_date, "%H:00")'), 'asc')
            ->select(
                DB::raw('DATE_FORMAT(log_date, "%H:00") as label'),
                DB::raw("COUNT(CASE WHEN direction = 'IN' THEN 1 ELSE NULL END) as total_in"),
                DB::raw("COUNT(CASE WHEN direction = 'OUT' THEN 1 ELSE NULL END) as total_out")
            )
            ->get();
    }

    /**
     * Choose a stop and display the evolution of ins and outs over the past 6-month period.
     */
    public function getSixMonthStopEvolution($stop)
    {
        $sixMonthsAgo = Carbon::now()->subMonths(6);

        return self::when($stop !== 'all', function ($query) use ($stop) {
            $query->where('stop_id', $stop);
        })->where('log_date', '>=', $sixMonthsAgo)
            ->groupBy(DB::raw("CONCAT(YEAR(log_date), '-', LPAD(MONTH(log_date), 2, '0'))"))
            ->orderBy(DB::raw("CONCAT(YEAR(log_date), '-', LPAD(MONTH(log_date), 2, '0'))"), 'asc')
            ->select(
                DB::raw("CONCAT(YEAR(log_date), '-', LPAD(MONTH(log_date), 2, '0')) as label"),
                DB::raw("COUNT(CASE WHEN direction = 'IN' THEN 1 ELSE NULL END) as total_in"),
                DB::raw("COUNT(CASE WHEN direction = 'OUT' THEN 1 ELSE NULL END) as total_out")                               
            )
            ->get();
    }

    /**
     * shows all the ins and outs of that month of chosen vehicle(s).
     */
    public function getVehicleMonthlyInsOuts($month, $vehicle)
    {
        return self::when($vehicle !== 'all', function ($query) use ($vehicle) {
            $query->where('vehicle_id', $vehicle);
        })->whereMonth('log_date', Carbon::parse($month)->month)
            ->whereYear('log_date', Carbon::parse($month)->year)
            ->groupBy(DB::raw('DATE(log_date)'))
            ->orderBy(DB::raw('DATE(log_date)'), 'asc')
            ->select(
                DB::raw('DATE(log_date) as label'),
                DB::raw("COUNT(CASE WHEN direction = 'IN' THEN 1 ELSE NULL END) as total_in"),
                DB::raw("COUNT(CASE WHEN direction = 'OUT' THEN 1 ELSE NULL END) as total_out")
            )
            ->get();

    }

    /**
     * Choose a stop and display for that stop the total ins and outs.
     */
    public function getStopTotalInsOuts($stop, $start_date, $end_date)
    {
        $logs = self::when($stop !== 'all', function ($query) use ($stop) {
            $query->where('stop_id', $stop);
        })->when($start_date !== '', function ($query) use ($start_date) {
            $query->where('log_date', '>=', Carbon::parse($start_date));
        })->when($end_date !== '', function ($query) use ($end_date) {
            $query->where('log_date', '<=', Carbon::parse($end_date));
        })->groupBy('vehicle_id')->select(
            DB::raw('vehicle_id as vehicle_id'),
            DB::raw("COUNT(CASE WHEN direction = 'IN' THEN 1 ELSE NULL END) as total_in"),
            DB::raw("COUNT(CASE WHEN direction = 'OUT' THEN 1 ELSE NULL END) as total_out")
        )->get();

        $vehicleNames = VehicleSetting::whereIn('id', $logs->pluck('vehicle_id'))->pluck('name', 'id');

        $logs->map(function ($log) use ($vehicleNames) {
            $log->label = $vehicleNames[$log->vehicle_id] ?? null;
            return $log;
        });

        return $logs;
    }

    /**
     * Choose a stop and display all days of the month all ins and outs.
     */
    public function getStopMonthlyDailyInsOuts($month, $stop)
    {
        $logs = self::when($stop !== 'all', function ($query) use ($stop) {
            $query->where('stop_id', $stop);
        })->whereMonth('log_date', Carbon::parse($month)->month)
            ->whereYear('log_date', Carbon::parse($month)->year)
            ->groupBy(DB::raw('DATE(log_date)'))
            ->orderBy(DB::raw('DATE(log_date)'), 'asc')
            ->select(
                DB::raw('DATE(log_date) as label'),
                DB::raw("COUNT(CASE WHEN direction = 'IN' THEN 1 ELSE NULL END) as total_in"),
                DB::raw("COUNT(CASE WHEN direction = 'OUT' THEN 1 ELSE NULL END) as total_out")
            )
            ->get();

        return $logs;
    }

    /**
     * Show the ins and outs per stop per weekday of the chosen month.
     */
    public function getStopMonthWeekdayInsOuts($month, $weekday)
    {
        $logs = self::whereMonth('log_date', Carbon::parse($month)->month)
            ->whereYear('log_date', Carbon::parse($month)->year)
            ->when($weekday !== 'all', function ($query) use ($weekday) {
                $query->whereRaw('LOWER(DAYNAME(log_date)) = ?', [strtolower($weekday)]);
            })
            ->groupBy('stop_id')
            ->select(
                DB::raw('stop_id as stop_id'),
                DB::raw("COUNT(CASE WHEN direction = 'IN' THEN 1 ELSE NULL END) as total_in"),
                DB::raw("COUNT(CASE WHEN direction = 'OUT' THEN 1 ELSE NULL END) as total_out")
            )
            ->get();

        $stopNames = VehicleStop::whereIn('id', $logs->pluck('stop_id'))->pluck('name', 'id');

        $logs->map(function ($log) use ($stopNames) {
            $log->label = $stopNames[$log->stop_id] ?? null;
            return $log;
        });

        return $logs;
    }
}
