<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VehicleStop extends Model
{
    protected $fillable = [
        'name',
        'latitude',
        'longitude',
        'address',
        'created_at',
        'updated_at',
        'is_active'
    ];

    public $incrementing = false; // Since 'id' is not auto-incrementing
    protected $keyType = 'string'; // 'id' is a UUID (CHAR(36))

    protected $casts = [
        'is_active' => 'boolean',
    ];
    
    public $table = 'vehicle_stops';
}
