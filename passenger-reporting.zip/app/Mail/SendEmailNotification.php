<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class SendEmailNotification extends Mailable
{
    use Queueable, SerializesModels;

    public $email_template;
    public $email_data;
    public $subject;

    /**
     * Create a new message instance.
     */
    public function __construct($email_template, $email_data, $subject)
    {
        $this->email_data = $email_data;
        $this->subject = $subject;
        $this->email_template = $email_template;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->subject,
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: $this->email_template,
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }

    public function build()
    {
        return $this->view($this->email_template) // Replace with your email view
            ->with('email_data', $this->email_data)
            ->subject($this->subject)
            ->from(config('constants.MAIL_FROM_ADDRESS'), config('constants.MAIL_FROM_NAME'));
    }
}
