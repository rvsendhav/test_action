<?php

namespace App\Services;

use App\Repositories\VehicleStop\VehicleStopInterface;

class VehicleStopService {

    private $vehicleStopInterface;

    public function __construct(VehicleStopInterface $vehicleStopInterface) {
        $this->vehicleStopInterface = $vehicleStopInterface;
    }

    public function create(array $data) {
        return $this->vehicleStopInterface->create($data);
    }

    public function fetch() {
        return $this->vehicleStopInterface->fetch();
    }

    public function update(string $id, array $data) {
        return $this->vehicleStopInterface->update($id, $data);
    }

    public function destroy(string $id) {
        return $this->vehicleStopInterface->destroy($id);
    }

    public function fetchAll($search = null) {
        return $this->vehicleStopInterface->fetchAll($search);
    }

    public function fetchByID(string $id) {
        return $this->vehicleStopInterface->fetchByID($id);
    }

    public function recordCount() {
        return $this->vehicleStopInterface->recordCount();
    }
}