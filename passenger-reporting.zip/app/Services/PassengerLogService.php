<?php

namespace App\Services;

use App\Repositories\PassengerLog\PassengerLogInterface;

class PassengerLogService {

    private $passengerLog;

    public function __construct(PassengerLogInterface $passengerLog) {
        $this->passengerLog = $passengerLog;
    }

    public function create(array $data) {
        return $this->passengerLog->create($data);
    }

    public function insert(array $data) {
        return $this->passengerLog->insert($data);
    }

    public function destroy(string $id) {
        return $this->passengerLog->destroy($id);
    }

    public function fetchAll() {
        return $this->passengerLog->fetchAll();
    }

    public function fetchExistsAll($data) {
        return $this->passengerLog->fetchExistsAll($data);
    }

    public function fetchByID(string $id) {
        return $this->passengerLog->fetchByID($id);
    }

    public function recordCount() {
        return $this->passengerLog->recordCount();
    }

    public function getDayTotalInsOuts($day) {
        return $this->passengerLog->getDayTotalInsOuts($day);
    }

    public function getDayHourlyInsOuts($day) {
        return $this->passengerLog->getDayHourlyInsOuts($day);
    }

    public function getSixMonthStopEvolution($stop) {
        return $this->passengerLog->getSixMonthStopEvolution($stop);
    }

    public function getVehicleMonthlyInsOuts($month, $vehicle) {
        return $this->passengerLog->getVehicleMonthlyInsOuts($month, $vehicle);
    }

    public function getStopTotalInsOuts($stop, $start_date, $end_date) {
        return $this->passengerLog->getStopTotalInsOuts($stop, $start_date, $end_date);
    }

    public function getStopMonthlyDailyInsOuts($month, $stop) {
        return $this->passengerLog->getStopMonthlyDailyInsOuts($month, $stop);
    }

    public function getStopMonthWeekdayInsOuts($month, $weekday) {
        return $this->passengerLog->getStopMonthWeekdayInsOuts($month, $weekday);
    }

}