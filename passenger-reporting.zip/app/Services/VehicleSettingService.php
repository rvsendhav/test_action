<?php

namespace App\Services;

use App\Repositories\VehicleSetting\VehicleSettingInterface;

class VehicleSettingService {

    private $vehicleSettingInterface;

    public function __construct(VehicleSettingInterface $vehicleSettingInterface) {
        $this->vehicleSettingInterface = $vehicleSettingInterface;
    }

    public function create(array $data) {
        return $this->vehicleSettingInterface->create($data);
    }

    public function update(string $id, array $data) {
        return $this->vehicleSettingInterface->update($id, $data);
    }

    public function destroy(string $id) {
        return $this->vehicleSettingInterface->destroy($id);
    }

    public function fetchAll($search = null) {
        return $this->vehicleSettingInterface->fetchAll($search);
    }

    public function fetch() {
        return $this->vehicleSettingInterface->fetch();
    }

    public function fetchByID(string $id) {
        return $this->vehicleSettingInterface->fetchByID($id);
    }

    public function recordCount() {
        return $this->vehicleSettingInterface->recordCount();
    }
}