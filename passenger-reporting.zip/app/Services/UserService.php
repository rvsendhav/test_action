<?php

namespace App\Services;

use App\Repositories\User\UserInterface;

class UserService {

    private $userInterface;

    public function __construct(UserInterface $userInterface) {
        $this->userInterface = $userInterface;
    }

    public function create(array $data) {
        return $this->userInterface->create($data);
    }

    public function update(string $id, array $data) {
        return $this->userInterface->update($id, $data);
    }

    public function destroy(string $id) {
        return $this->userInterface->destroy($id);
    }

    public function fetchAll(array $user_types = [], array $excludes_users = [], string $search = null) {
        return $this->userInterface->fetchAll($user_types, $excludes_users, $search);
    }

    public function fetchByID(string $id) {
        return $this->userInterface->fetchByID($id);
    }

    public function fetchByEmail(string $email, array $user_types) {
        return $this->userInterface->fetchByEmail($email, $user_types);
    }
    
    public function verifyEmail(string $id) {
        return $this->userInterface->verifyEmail($id);
    }

    public function recordCount($user_types, array $excludes_users = []) {
        return $this->userInterface->recordCount($user_types, $excludes_users);
    }

}