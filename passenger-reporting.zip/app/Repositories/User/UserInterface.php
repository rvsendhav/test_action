<?php

namespace App\Repositories\User;

interface UserInterface
{
    public function create(array $data);

    public function update(string $id, array $data);

    public function destroy(string $id);

    public function fetchAll(array $user_types = [], array $excludes_users = [], string $search = null);

    public function fetchByID(string $id);

    public function fetchByEmail(string $email, array $user_types);
        
    public function verifyEmail(string $id);

    public function recordCount($user_types, array $excludes_users = []);

}