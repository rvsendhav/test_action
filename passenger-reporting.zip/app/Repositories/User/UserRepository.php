<?php

namespace App\Repositories\User;

use App\Models\User;

class UserRepository implements UserInterface
{
    private $instance;

    public function __construct(User $instance)
    {
        $this->instance = $instance;
    }

    public function create(array $data)
    {
        try {
            return $this->instance->create($data);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function update(string $id, array $data)
    {
        try {
            return $this->instance->where('id', $id)->update($data);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function destroy(string $id)
    {
        try {
            $record = $this->instance->where('id', $id)->first();
            return $record->delete();
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function fetchAll($user_types = [], $excludes_users = [], string $search = null)
    {
        try {
            $users = $this->instance->whereNotIn('id', $excludes_users);
            if ($user_types) {
                $users->whereIn('user_type', $user_types);
            }
            return $users->where(function ($query) use ($search) {
                    return $query->where('name', 'LIKE', "%{$search}%")
                        ->orWhere('email', 'LIKE', "%{$search}%");
                })
                ->orderby('id', 'ASC')
                ->paginate(config('constants.DEFAULT_PAGES') ?? 10);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function fetchByEmail(string $email, array $user_types)
    {
        try {
            $user = $this->instance->where('email', $email);
            if ($user_types) {
                $user->whereIn('user_type', $user_types);
            }
            return $user->first();
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function fetchByID(string $id)
    {
        try {
            return $this->instance->where('id', $id)->first();
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function verifyEmail($id)
    {
        try {
            $model = $this->instance->where('id', $id)->first();
            if ($model) {
                $model->is_email_verified = true;
                $model->save();
            }
            return $model;
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function recordCount($user_types, $excludes_users = [])
    {
        try {
            return $this->instance->whereIn('user_type', $user_types)->whereNotIn('id', $excludes_users)->count();
        } catch (\Exception $e) {
            throw $e;
        }
    }

}
