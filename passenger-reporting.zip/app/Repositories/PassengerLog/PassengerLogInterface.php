<?php

namespace App\Repositories\PassengerLog;

interface PassengerLogInterface
{
    public function create(array $data);

    public function insert(array $data);

    public function destroy(string $id);

    public function fetchAll();
    
    public function fetchExistsAll(array $data);

    public function fetchByID(string $id);
    
    public function recordCount();

    public function getDayTotalInsOuts($day);

    public function getDayHourlyInsOuts($day);

    public function getSixMonthStopEvolution($stop);

    public function getVehicleMonthlyInsOuts($month, $vehicle);

    public function getStopTotalInsOuts($stop, $start_date, $end_date);

    public function getStopMonthlyDailyInsOuts($month, $stop);

    public function getStopMonthWeekdayInsOuts($month, $weekday);

}