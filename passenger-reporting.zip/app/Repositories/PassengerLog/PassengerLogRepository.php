<?php

namespace App\Repositories\PassengerLog;

use App\Models\PassengerLog;

class PassengerLogRepository implements PassengerLogInterface
{
    private $instance;

    public function __construct(PassengerLog $instance)
    {
        $this->instance = $instance;
    }

    public function create(array $data)
    {
        try {
            return $this->instance->create($data);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function insert(array $data)
    {
        try {
            return $this->instance->insert($data);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function destroy(string $id)
    {
        try {
            $record = $this->instance->where('id', $id)->first();
            return $record->delete();
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function fetchAll()
    {
        try {
            return $this->instance::with(['vehicle', 'stop'])
                ->orderby('id', 'ASC')
                ->paginate(config('constants.DEFAULT_PAGES') ?? 10);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function fetchExistsAll(array $data) {
        return $this->instance->where(function ($query) use ($data) {
            foreach ($data as $v) {
                $query->orWhere(function ($subQuery) use ($v) {
                    $subQuery->where('latitude', $v["latitude"])
                             ->where('longitude', $v["longitude"])
                             ->where('vehicle_id', $v["vehicle_id"])
                             ->where('log_date', '=', $v["log_date"])
                             ->where('direction', '=', $v["direction"]);  // Use where for exact datetime match
                });
            }
        })->get();        
    }

    public function fetchByID(string $id)
    {
        try {
            return $this->instance->where('id', $id)->first();
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function recordCount()
    {
        try {
            return $this->instance->count();
        } catch (\Exception $e) {
            throw $e;
        }
    }


    public function getDayTotalInsOuts($day) {
        try {
            return $this->instance->getDayTotalInsOuts($day);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function getDayHourlyInsOuts($day) {
        try {
            return $this->instance->getDayHourlyInsOuts($day);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function getSixMonthStopEvolution($stop) {
        try {
            return $this->instance->getSixMonthStopEvolution($stop);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function getVehicleMonthlyInsOuts($month, $vehicle) {
        try {
            return $this->instance->getVehicleMonthlyInsOuts($month, $vehicle);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function getStopTotalInsOuts($stop, $start_date, $end_date) {
        try {
            return $this->instance->getStopTotalInsOuts($stop, $start_date, $end_date);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function getStopMonthlyDailyInsOuts($month, $stop) {
        try {
            return $this->instance->getStopMonthlyDailyInsOuts($month, $stop);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function getStopMonthWeekdayInsOuts($month, $weekday) {
        try {
            return $this->instance->getStopMonthWeekdayInsOuts($month, $weekday);
        } catch (\Exception $e) {
            throw $e;
        }
    }

}
