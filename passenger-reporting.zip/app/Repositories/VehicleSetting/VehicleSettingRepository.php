<?php

namespace App\Repositories\VehicleSetting;

use App\Models\VehicleSetting;

class VehicleSettingRepository implements VehicleSettingInterface
{
    private $instance;

    public function __construct(VehicleSetting $instance)
    {
        $this->instance = $instance;
    }

    public function create(array $data)
    {
        try {
            return $this->instance->create($data);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function update(string $id, array $data)
    {
        try {
            return $this->instance->where('id', $id)->update($data);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function destroy(string $id)
    {
        try {
            $record = $this->instance->where('id', $id)->first();
            return $record->delete();
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function fetchAll(string $search = null)
    {
        try {
            return $this->instance->where(function ($query) use ($search) {
                return $query->where('name', 'LIKE', "%{$search}%");
            })
                ->orderby('id', 'ASC')
                ->paginate(config('constants.DEFAULT_PAGES') ?? 10);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function fetch()
    {
        try {
            return $this->instance->orderby('name', 'ASC')->get();
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function fetchByID(string $id)
    {
        try {
            return $this->instance->where('id', $id)->first();
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function recordCount()
    {
        try {
            return $this->instance->count();
        } catch (\Exception $e) {
            throw $e;
        }
    }

}
