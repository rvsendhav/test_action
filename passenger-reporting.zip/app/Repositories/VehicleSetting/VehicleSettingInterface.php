<?php

namespace App\Repositories\VehicleSetting;

interface VehicleSettingInterface
{
    public function create(array $data);

    public function update(string $id, array $data);

    public function destroy(string $id);

    public function fetchAll(string $search = null);

    public function fetch();

    public function fetchByID(string $id);
    
    public function recordCount();
}