<?php

namespace App\Http\Requests\Web;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException as HttpResponse;

class ResetPasswordRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'email' => 'required|string|email|max:255',
            'password' => 'required|string|min:8|regex:/[a-z]/|regex:/[A-Z]/|regex:/[0-9]/|confirmed',
            'password_confirmation' => 'required|string',
            'token' => 'required'
        ];

        return $rules;
    }

    // Custom messages for validation errors.
    public function messages()
    {
        return [
            'password.required' => 'Password is required.',
            'password.min' => 'Your password must be at least 8 characters long.',
            'password.regex' => 'Your password must include at least one lowercase letter, one uppercase letter, and one number.',
        ];
    }
}
