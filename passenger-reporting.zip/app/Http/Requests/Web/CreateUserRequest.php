<?php

namespace App\Http\Requests\Web;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException as HttpResponse;

class CreateUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            'new_password' => 'required|string|min:8|regex:/[a-z]/|regex:/[A-Z]/|regex:/[0-9]/|confirmed',
            'new_password_confirmation' => 'required|string'
        ];

        return $rules;
    }

    // Custom messages for validation errors.
    public function messages()
    {
        return [
            'new_password.required' => 'Password is required.',
            'new_password.min' => 'Your password must be at least 8 characters long.',
            'new_password.regex' => 'Your password must include at least one lowercase letter, one uppercase letter, and one number.',
        ];
    }
}
