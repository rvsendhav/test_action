<?php

namespace App\Http\Controllers\Web;

use App\Exceptions\CustomException;
use App\Http\Controllers\Controller;
use App\Http\Requests\Web\ChangePasswordRequest;
use App\Http\Requests\Web\UpdateProfileRequest;
use App\Services\UserService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class UserController extends Controller
{
    protected $userService;

    public function __construct(UserService $userService)
    {
        parent::__construct();
        $this->userService = $userService;
    }

    public function logout()
    {
        try {
            Auth::logout();
            Session::flush();
            return redirect()->route('web.login.view');
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function index()
    {
        try {
            $auth_user = Auth::user();
            $user = $this->userService->fetchByID($auth_user->id);
            return view('dashboard.profile.index', compact(["user", "auth_user"]));
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function changePassword()
    {
        try {
            $auth_user = Auth::user();
            return view('dashboard.profile.change-password', compact(["auth_user"]));
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function updatePassword(ChangePasswordRequest $request)
    {
        try {
            $auth_user = Auth::user();
            $user = $this->userService->fetchByID($auth_user->id);
            if (!$user || !Hash::check($request->old_password, $user->password)) {
                throw new CustomException(__("messages.admin_dashboard_messages.wrong_old_password"), 422);
            } else {
                $this->userService->update($auth_user->id, ['password' => Hash::make($request->new_password)]);
                session()->flash('success', __("messages.admin_dashboard_messages.password_change_success"));
                return redirect()->route('web.dashboard.change-password');
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function updateProfile(UpdateProfileRequest $request)
    {
        try {
            $auth_user = Auth::user();
            $this->userService->update($auth_user->id, ['name' => $request->name]);
            session()->flash('success', __("messages.admin_dashboard_messages.profile_update_success"));
            return redirect()->route('web.dashboard.profile');
        } catch (\Exception $e) {
            throw $e;
        }
    }
}
