<?php

namespace App\Http\Controllers\Web;

use App\Exceptions\CustomException;
use App\Helpers\CustomHelper;
use App\Helpers\SendEmailHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\Web\CreateUserRequest;
use App\Http\Requests\Web\UpdateUserRequest;
use App\Services\UserService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Tymon\JWTAuth\Facades\JWTAuth;

class UsersController extends Controller
{
    protected $userService;

    public function __construct(UserService $userService)
    {
        parent::__construct();
        $this->userService = $userService;
    }

    public function index(Request $request)
    {
        try {
            $auth_user = Auth::user();
            if ($auth_user && $auth_user->user_type !== 'Admin') {
                throw new CustomException(__("messages.admin_dashboard_messages.unauthorized_access"), 422);
            } else {
                $page = $request->input('page');
                $search = $request->input('search');
                if ($auth_user && $auth_user->user_type === CustomHelper::userType("ADMIN")) {
                    $total_users = $this->userService->recordCount([CustomHelper::userType("ADMIN"), CustomHelper::userType("SUBADMIN")], [$auth_user->id]);
                    $users = $this->userService->fetchAll([CustomHelper::userType("ADMIN"), CustomHelper::userType("SUBADMIN")], [$auth_user->id], $search);
                } else {
                    $total_users = $this->userService->recordCount([CustomHelper::userType("SUBADMIN")], [$auth_user->id]);
                    $users = $this->userService->fetchAll([CustomHelper::userType("SUBADMIN")], [$auth_user->id], $search);
                }
                return view('dashboard.user.index', compact(["users", 'auth_user', "search", "total_users", "page"]));
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function create()
    {
        try {
            $auth_user = Auth::user();
            if ($auth_user && $auth_user->user_type !== 'Admin') {
                throw new CustomException(__("messages.admin_dashboard_messages.unauthorized_access"), 422);
            } else {
                return view('dashboard.user.create', compact(["auth_user"]));
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function store(CreateUserRequest $request)
    {
        try {
            $userEmail = $this->userService->fetchByEmail($request->email, [CustomHelper::userType("ADMIN"), CustomHelper::userType("SUBADMIN")]);
            if ($userEmail) {
                throw new CustomException(__("messages.admin_dashboard_messages.email_exists"), 422);
            } else {
                $this->userService->create([
                    'name' => $request->name,
                    'email' => $request->email,
                    'password' => Hash::make($request->new_password),
                    'user_type' => CustomHelper::userType("SUBADMIN"),
                    'is_email_verified' => true,
                    'is_active' => true,
                ]);
                session()->flash('success', __("messages.admin_dashboard_messages.admin_create_success"));
                return redirect()->route('users.index');
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function edit($id)
    {
        try {
            $auth_user = Auth::user();
            if ($auth_user && $auth_user->user_type !== 'Admin') {
                throw new CustomException(__("messages.admin_dashboard_messages.unauthorized_access"), 422);
            } else {
                $user = $this->userService->fetchByID($id);
                return view('dashboard.user.edit', compact(["user", "auth_user"]));
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function update(UpdateUserRequest $request, $id)
    {
        try {
            $this->userService->update($id, [
                'name' => $request->name,
            ]);
            session()->flash('success', __("messages.admin_dashboard_messages.admin_update_success"));
            return redirect()->route('users.index');
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function show($id)
    {
        try {
            $auth_user = Auth::user();
            if ($auth_user && $auth_user->user_type !== 'Admin') {
                throw new CustomException(__("messages.admin_dashboard_messages.unauthorized_access"), 422);
            } else {
                $user = $this->userService->fetchByID($id);
                return view('dashboard.user.view', compact(["user", "auth_user"]));
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function updateStatus(Request $request, $id)
    {
        try {
            if (isset($request->type) && $request->type === 'is_active') {
                $this->userService->update($id, [
                    "is_active" => $request->is_active == "true" ? 1 : 0,
                ]);
            }
            return response()->json(['success' => true, 'message' => __("messages.admin_dashboard_messages.data_updated_success")]);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function resetPassword($id)
    {
        try {
            $auth_user = Auth::user();
            if ($auth_user && $auth_user->user_type !== 'Admin') {
                throw new CustomException(__("messages.admin_dashboard_messages.unauthorized_access"), 422);
            } else {
                $user = $this->userService->fetchByID($id);
                return view('dashboard.user.reset-password', compact(["user", "auth_user"]));
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function sendResetPasswordLink(Request $request)
    {
        try {
            $user = $this->userService->fetchByID($request->id);

            $expiration = Carbon::now()->addMinutes(intval(config("constants.PASSWORD_RESET_LINK_EXPIRY")) ?? 30)->timestamp;

            $customClaims = [
                'exp' => $expiration,
                'email' => $user->email,
            ];

            $passwordResetToken = JWTAuth::fromUser($user, $customClaims);
            $this->userService->update($user->id, ["password_reset_token" => $passwordResetToken]);

            $passwordResetLink = url('/reset-password/' . $passwordResetToken);

            $payload = [
                'template' => "emails.forgot-password",
                'subject' => "Reset Password Email",
                'to_email' => $user->email,
                'to_name' => $user->name,
                'email_data' => [
                    "name" => $user->name,
                    "reset_link" => $passwordResetLink,
                ],
            ];
            SendEmailHelper::sendEmail($payload);
            session()->flash('success', __("messages.admin_dashboard_messages.email_sent"));
            return redirect()->route('users.index');
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function destroy($id)
    {
        try {

            $this->userService->destroy($id);
            session()->flash('success', __("messages.admin_dashboard_messages.record_deleted_success"));
            return redirect()->route('users.index');
        } catch (\Exception $e) {
            throw $e;
        }
    }
}
