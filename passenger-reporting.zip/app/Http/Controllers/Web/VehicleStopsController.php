<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Web\CreateVehicleStopRequest;
use App\Http\Requests\Web\UpdateVehicleStopRequest;
use App\Services\VehicleStopService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class VehicleStopsController extends Controller
{

    protected $vehicleStopService;

    public function __construct(VehicleStopService $vehicleStopService)
    {
        parent::__construct();
        $this->vehicleStopService = $vehicleStopService;
    }

    public function index(Request $request)
    {
        try {
            $page = $request->input('page');
            $auth_user = Auth::user();
            $search = $request->input('search');
            $total_vehicle_stops = $this->vehicleStopService->recordCount();
            $vehicle_stops = $this->vehicleStopService->fetchAll($search);
            return view('dashboard.vehicle_stops.index', compact(["vehicle_stops", 'auth_user', "search", "total_vehicle_stops", "page"]));
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function create()
    {
        try {
            $auth_user = Auth::user();
            return view('dashboard.vehicle_stops.create', compact(["auth_user"]));
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function store(CreateVehicleStopRequest $request)
    {
        try {
            $this->vehicleStopService->create([
                'name' => $request->name,
                'latitude' => $request->latitude ?? '',
                'address' => $request->address ?? '',
                'longitude' => $request->longitude ?? '',
            ]);
            session()->flash('success', __("messages.admin_dashboard_messages.vehicle_create_success"));
            return redirect()->route('vehicle-stops.index');
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function edit($id)
    {
        try {
            $auth_user = Auth::user();
            $vehicle_stop = $this->vehicleStopService->fetchByID($id);
            return view('dashboard.vehicle_stops.edit', compact(["vehicle_stop", "auth_user"]));
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function update(UpdateVehicleStopRequest $request, $id)
    {
        try {
            $this->vehicleStopService->update($id, [
                'name' => $request->name,
                'latitude' => $request->latitude ?? '',
                'address' => $request->address ?? '',
                'longitude' => $request->longitude ?? '',
            ]);
            session()->flash('success', __("messages.admin_dashboard_messages.data_updated_success"));
            return redirect()->route('vehicle-stops.index');
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function updateStatus(Request $request, string $id)
    {
        try {
            if (isset($request->type) && $request->type === 'is_active') {
                $this->vehicleStopService->update($id, [
                    "is_active" => $request->is_active == "true" ? 1 : 0,
                ]);
            }
            return response()->json(['success' => true, 'message' => __("messages.admin_dashboard_messages.data_updated_success")]);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function destroy($id)
    {
        try {
            $this->vehicleStopService->destroy($id);
            session()->flash('success', __("messages.admin_dashboard_messages.record_deleted_success"));
            return redirect()->route('vehicle-stops.index');
        } catch (\Exception $e) {
            throw $e;
        }
    }
}
