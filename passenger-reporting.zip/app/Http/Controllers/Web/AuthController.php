<?php

namespace App\Http\Controllers\Web;

use App\Exceptions\CustomException;
use App\Helpers\CustomHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\Web\LoginRequest;
use App\Http\Requests\Web\ResetPasswordRequest;
use App\Services\UserService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Tymon\JWTAuth\Facades\JWTAuth;

class AuthController extends Controller
{
    protected $userService;

    public function __construct(UserService $userService)
    {
        parent::__construct();
        $this->userService = $userService;
    }

    public function index()
    {
        return view('auth.login');
    }

    public function pageNotFound()
    {
        return view('error.404');
    }

    public function unauthorizedAccess()
    {
        return view('error.401');
    }

    public function loginPost(LoginRequest $request)
    {
        try {
            $user = $this->userService->fetchByEmail($request->email, [CustomHelper::userType("ADMIN"), CustomHelper::userType("SUBADMIN")]);
            if (!$user || !Hash::check($request->password, $user->password)) {
                throw new CustomException(__("messages.admin_dashboard_messages.invalid_credentials"), 422);
            } elseif ($user && !$user->is_email_verified) {
                throw new CustomException(__("messages.admin_dashboard_messages.email_not_verfied"), 422);
            } elseif ($user && !$user->is_active) {
                throw new CustomException(__("messages.admin_dashboard_messages.account_blocked"), 422);
            } elseif ($user) {
                Auth::login($user);
                return redirect()->route('web.dashboard.view');
            } else {
                throw new CustomException(__("messages.admin_dashboard_messages.user_not_found"), 422);
            }
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function resetPassword($token)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            return view('auth.reset-password', ['email' => $user->email, 'token' => $token]);
        } catch (TokenExpiredException $e) {
            throw new CustomException(__("messages.admin_dashboard_messages.token_expired"), 422, ['token' => $token], "web.reset-password");
        } catch (TokenInvalidException $e) {
            throw new CustomException(__("messages.admin_dashboard_messages.token_invalid"), 422, ['token' => $token], "web.reset-password");
        } catch (JWTException $e) {
            throw new CustomException(__("messages.admin_dashboard_messages.token_issue"), 422, ['token' => $token], "web.reset-password");
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function updatePassword(ResetPasswordRequest $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $email = $user->email;

            if ($email !== $request->email) {
                throw new CustomException(__("messages.admin_dashboard_messages.invalid_email"), 422, ['token' => $request->token], "web.reset-password");

            }
            $user = $this->userService->fetchByEmail($email, [$user->user_type]);

            if (!$user) {
                throw new CustomException(__("messages.admin_dashboard_messages.user_not_found"), 422, ['token' => $request->token], "web.reset-password");
            } else if ($user && !$user->password_reset_token) {
                throw new CustomException(__("messages.admin_dashboard_messages.token_expired"), 422, ['token' => $request->token], "web.reset-password");
            } else if ($user->password_reset_token != $request->token) {
                throw new CustomException(__("messages.admin_dashboard_messages.not_authorized"), 422, ['token' => $request->token], "web.reset-password");
            }
            $user->password = Hash::make($request->password);
            $user->save();
            $this->userService->update($user->id, ["password_reset_token" => null]);
            session()->flash('success', __("messages.admin_dashboard_messages.password_change_success"));
            return redirect()->route('web.reset-password', ['token' => $request->token]);
        } catch (TokenExpiredException $e) {
            throw new CustomException(__("messages.admin_dashboard_messages.token_expired"), 422, ['token' => $request->token], "web.reset-password");
        } catch (TokenInvalidException $e) {
            throw new CustomException(__("messages.admin_dashboard_messages.token_invalid"), 422, ['token' => $request->token], "web.reset-password");
        } catch (JWTException $e) {
            throw new CustomException(__("messages.admin_dashboard_messages.token_issue"), 422, ['token' => $request->token], "web.reset-password");
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function verifyEmail($token)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $email = $user->email;

            $user = $this->userService->fetchByEmail($email, [$user->user_type]);

            if (!$user) {
                return view('auth.verify-email', ['message' => "User not found."]);
            } else if ($user->is_email_verified) {
                return view('auth.verify-email', ['message' => "Email already verified."]);
            } else if ($user && !$user->email_verify_token) {
                return view('auth.verify-email', ['message' => "The token has expired."]);
            } else if ($user->email_verify_token != $token) {
                return view('auth.verify-email', ['message' => "You are not authorize to perform the action."]);
            }

            $this->userService->update($user->id, ["email_verify_token" => null, "is_email_verified" => true]);

            return view('auth.verify-email', ['message' => "Email verified successfully."]);

        } catch (TokenExpiredException $e) {
            return view('auth.verify-email', ['message' => "The token has expired."]);
        } catch (TokenInvalidException $e) {
            return view('auth.verify-email', ['message' => "The token is invalid."]);
        } catch (JWTException $e) {
            return view('auth.verify-email', ['message' => "There was an issue with the token."]);
        } catch (\Exception $e) {
            throw $e;
        }
    }
}
