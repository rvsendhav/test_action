<?php

namespace App\Http\Controllers\Web;

use App\Exceptions\CustomException;
use App\Helpers\GeoFenchHelper;
use App\Http\Controllers\Controller;
use App\Services\PassengerLogService;
use App\Services\VehicleSettingService;
use App\Services\VehicleStopService;
use Carbon\Carbon;
use DateTimeZone;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use PhpOffice\PhpSpreadsheet\IOFactory;

class PassengerLogController extends Controller
{

    protected $passengerLogService;
    protected $vehicleStopService;
    protected $vehicleSettingService;

    public function __construct(VehicleStopService $vehicleStopService, VehicleSettingService $vehicleSettingService, PassengerLogService $passengerLogService)
    {
        parent::__construct();
        $this->passengerLogService = $passengerLogService;
        $this->vehicleStopService = $vehicleStopService;
        $this->vehicleSettingService = $vehicleSettingService;
    }

    public function index(Request $request)
    {
        try {
            $page = $request->input('page');
            $auth_user = Auth::user();
            $search = $request->input('search');
            $total_passenger_logs = $this->passengerLogService->recordCount();
            $passenger_logs = $this->passengerLogService->fetchAll();
            return view('dashboard.passenger_logs.index', compact(["passenger_logs", 'auth_user', "search", "total_passenger_logs", "page"]));
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function create(Request $request)
    {
        try {
            $auth_user = Auth::user();
            return view('dashboard.passenger_logs.upload', compact(["auth_user"]));
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function store(Request $request)
    {
        try {
            $auth_user = Auth::user();
            $file = $request->file('file');
            $spreadsheet = IOFactory::load($file->getRealPath());
            $sheet = $spreadsheet->getActiveSheet();
            $data = $sheet->toArray();

            // Fetch necessary services and data
            $vehicles = $this->vehicleSettingService->fetch();
            $stops = $this->vehicleStopService->fetch();

            // Filter and process data
            $filteredData = $this->filterData($data);
            $geoFences = GeoFenchHelper::generateGeoFences($stops);

            // Map data to the desired format
            $mappedData = $this->mapData($filteredData, $geoFences, $vehicles);

            // Validate the processed data
            $validationResult = $this->validateData($mappedData);
            if ($validationResult['error']) {
                throw new CustomException($validationResult['message'], 422);
            }

            $mappedData = $this->filterDuplicateData($mappedData);

            $this->passengerLogService->insert($mappedData);
            session()->flash('success', __("messages.admin_dashboard_messages.report_upload_success"));
            return redirect()->route('passenger-logs.index');
        } catch (\Exception $e) {
            throw $e;
        }
    }

    private function filterData($data)
    {
        $columnsValues = array_values($data[0]);

        $indexLatitude = array_search("Latitude", $columnsValues);
        $indexLongitude = array_search("Longitude", $columnsValues);
        $indexUnit = array_search("Unit", $columnsValues);
        $indexDirection = array_search("Direction", $columnsValues);
        $indexTime = array_search("Time", $columnsValues);

        return array_filter($data, function ($row) use ($indexLatitude, $indexLongitude, $indexUnit, $indexDirection, $indexTime) {
            return !empty($row[$indexLatitude]) && !empty($row[$indexLongitude]) && !empty($row[$indexUnit]) && !empty($row[$indexDirection]) && !empty($row[$indexTime]);
        });
    }

    private function mapData($data, $geoFences, $vehicles)
    {
        $columnsValues = array_values($data[0]);
        $indexUnit = array_search("Unit", $columnsValues);
        $indexDirection = array_search("Direction", $columnsValues);
        $indexTime = array_search("Time", $columnsValues);
        $indexLatitude = array_search("Latitude", $columnsValues);
        $indexLongitude = array_search("Longitude", $columnsValues);

        unset($data[0]); // Remove header row

        return array_map(function ($v) use ($indexUnit, $indexDirection, $indexTime, $indexLatitude, $indexLongitude, $vehicles, $geoFences) {
            $latitude = (double) str_replace(',', '.', str_replace(',', '', $v[$indexLatitude]));
            $longitude = (double) str_replace(',', '.', str_replace(',', '', $v[$indexLongitude]));
            $nearestStop = GeoFenchHelper::findNearestStop($latitude, $longitude, $geoFences);

            return [
                "stop_id" => $nearestStop ? $nearestStop['id'] : null,
                "vehicle_id" => GeoFenchHelper::findVehicleId($vehicles, $v[$indexUnit]),
                'log_date' => Carbon::parse($v[$indexTime], new DateTimeZone(date_default_timezone_get()))
                    ->setTimezone(new DateTimeZone('UTC'))
                    ->toDateTimeString(),
                'direction' => $v[$indexDirection],
                'latitude' => $latitude,
                'longitude' => $longitude,
            ];
        }, $data);
    }

    private function validateData($data)
    {
        $stopIdWithNull = array_filter($data, fn($item) => is_null($item["stop_id"]));
        $vehicleIdWithNull = array_filter($data, fn($item) => is_null($item["vehicle_id"]));
        $invalidDirection = array_filter($data, fn($item) => !($item["direction"] == 'IN' || $item["direction"] == 'OUT'));

        if (!empty($stopIdWithNull)) {
            return ['error' => true, 'message' => __("messages.admin_dashboard_messages.report_validation_stop_error")];
        } elseif (!empty($vehicleIdWithNull)) {
            return ['error' => true, 'message' => __("messages.admin_dashboard_messages.report_validation_vehicle_error")];
        } elseif (!empty($invalidDirection)) {
            return ['error' => true, 'message' => __("messages.admin_dashboard_messages.report_validation_direction_error")];
        }

        return ['error' => false];
    }

    private function filterDuplicateData($data)
    {
        $duplicateData = $this->passengerLogService->fetchExistsAll($data)->toArray();

        return array_filter($data, function ($v) use ($duplicateData) {
            foreach ($duplicateData as $dup) {
                if (
                    $v["latitude"] === $dup["latitude"] &&
                    $v["longitude"] === $dup["longitude"] &&
                    $v["vehicle_id"] === $dup["vehicle_id"] &&
                    $v["log_date"] === $dup["log_date"] &&
                    $v["direction"] === $dup["direction"]
                ) {
                    return false;
                }
            }
            return true;
        });
        
    }

    public function destroy($id)
    {
        try {
            session()->flash('success', __("messages.admin_dashboard_messages.record_deleted_success"));
            return redirect()->route('passenger-logs.index');
        } catch (\Exception $e) {
            throw $e;
        }
    }
}
