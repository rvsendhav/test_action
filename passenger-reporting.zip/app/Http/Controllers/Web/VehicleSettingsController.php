<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Web\CreateVehicleSettingRequest;
use App\Http\Requests\Web\UpdateVehicleSettingRequest;
use App\Services\VehicleSettingService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class VehicleSettingsController extends Controller
{

    protected $vehicleSettingService;

    public function __construct(VehicleSettingService $vehicleSettingService)
    {
        parent::__construct();
        $this->vehicleSettingService = $vehicleSettingService;
    }

    public function index(Request $request)
    {
        try {
            $page = $request->input('page');
            $auth_user = Auth::user();
            $search = $request->input('search');
            $total_vehicle_settings = $this->vehicleSettingService->recordCount();
            $vehicle_settings = $this->vehicleSettingService->fetchAll($search);
            return view('dashboard.vehicle_settings.index', compact(["vehicle_settings", 'auth_user', "search", "total_vehicle_settings", "page"]));
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function create()
    {
        try {
            $auth_user = Auth::user();
            return view('dashboard.vehicle_settings.create', compact(["auth_user"]));
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function store(CreateVehicleSettingRequest $request)
    {
        try {
            $this->vehicleSettingService->create([
                'name' => $request->name,
            ]);
            session()->flash('success', __("messages.admin_dashboard_messages.vehicle_setting_create_success"));
            return redirect()->route('vehicle-settings.index');
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function edit($id)
    {
        try {
            $auth_user = Auth::user();
            $vehicle_setting = $this->vehicleSettingService->fetchByID($id);
            return view('dashboard.vehicle_settings.edit', compact(["vehicle_setting", "auth_user"]));
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function update(UpdateVehicleSettingRequest $request, $id)
    {
        try {
            $this->vehicleSettingService->update($id, [
                'name' => $request->name,
            ]);
            session()->flash('success', __("messages.admin_dashboard_messages.data_updated_success"));
            return redirect()->route('vehicle-settings.index');
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function updateStatus(Request $request, string $id)
    {
        try {
            if (isset($request->type) && $request->type === 'is_active') {
                $this->vehicleSettingService->update($id, [
                    "is_active" => $request->is_active == "true" ? 1 : 0,
                ]);
            }
            return response()->json(['success' => true, 'message' => __("messages.admin_dashboard_messages.data_updated_success")]);
        } catch (\Exception $e) {
            throw $e;
        }
    }

    public function destroy($id)
    {
        try {
            $this->vehicleSettingService->destroy($id);
            session()->flash('success', __("messages.admin_dashboard_messages.record_deleted_success"));
            return redirect()->route('vehicle-settings.index');
        } catch (\Exception $e) {
            throw $e;
        }
    }
}
