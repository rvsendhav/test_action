<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Services\PassengerLogService;
use App\Services\VehicleSettingService;
use App\Services\VehicleStopService;
use App\Services\UserService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Helpers\CustomHelper;

class DashboardController extends Controller
{
    protected $vehicleStopService;
    protected $vehicleSettingService;
    protected $passengerLogService;
    protected $userService;

    public function __construct(VehicleStopService $vehicleStopService, VehicleSettingService $vehicleSettingService, PassengerLogService $passengerLogService, UserService $userService)
    {
        parent::__construct();
        $this->vehicleStopService = $vehicleStopService;
        $this->vehicleSettingService = $vehicleSettingService;
        $this->passengerLogService = $passengerLogService;
        $this->userService = $userService;
    }

    public function index(Request $request)
    {
        $auth_user = Auth::user();
        $total_vehicle_stops = $this->vehicleStopService->recordCount();
        $total_vehicle_settings = $this->vehicleSettingService->recordCount();
        $total_passenger_logs = $this->passengerLogService->recordCount();
        if( $auth_user && $auth_user->user_type === CustomHelper::userType("ADMIN") ) {
            $total_users = $this->userService->recordCount([CustomHelper::userType("ADMIN"), CustomHelper::userType("SUBADMIN")], [$auth_user->id]);
        } else {
            $total_users = $this->userService->recordCount([CustomHelper::userType("SUBADMIN")], [$auth_user->id]);
        }
        return view('dashboard.index', compact(
            'auth_user',
            'total_vehicle_stops',
            'total_vehicle_settings',
            'total_passenger_logs',
            'total_users'
        ));
    }
    public function vehicleMonthlyInsOutsReporting(Request $request)
    {
        $month = $request->input('month', date('Y-m'));
        $vehicle = $request->input('vehicle', 'all');
        $auth_user = Auth::user();
        $vehicles = $this->vehicleSettingService->fetch();
        $data = $this->passengerLogService->getVehicleMonthlyInsOuts($month, $vehicle);

        return view('dashboard.passenger_reports.vehicle-monthly-ins-outs', compact(
            'data',
            'vehicles',
            'month',
            'vehicle',
            'auth_user'
        ));
    }
    public function stopTotalInsOutsReporting(Request $request)
    {
        $stop = $request->input('stop', 'all');
        $start_date = $request->input('start_date', '');
        $end_date = $request->input('end_date', '');
        if (!$start_date) {
            $start_date = "";
        }
        if (!$end_date) {
            $end_date = "";
        }
        $auth_user = Auth::user();
        $stops = $this->vehicleStopService->fetch();
        $data = $this->passengerLogService->getStopTotalInsOuts($stop, $start_date, $end_date);

        return view('dashboard.passenger_reports.stop-total-ins-outs', compact(
            'data',
            'stops',
            'stop',
            'auth_user',
            'start_date',
            'end_date'
        ));
    }

    public function stopMonthlyDailyInsOutsReporting(Request $request)
    {
        $month = $request->input('month', date('Y-m'));
        $stop = $request->input('stop', 'all');
        $auth_user = Auth::user();
        $stops = $this->vehicleStopService->fetch();
        $data = $this->passengerLogService->getStopMonthlyDailyInsOuts($month, $stop);

        return view('dashboard.passenger_reports.stop-monthly-daily-ins-outs', compact(
            'data',
            'stops',
            'month',
            'stop',
            'auth_user'
        ));
    }

    public function stopMonthWeekdayInsOutsReporting(Request $request)
    {
        $month = $request->input('month', date('Y-m'));
        $weekday = $request->input('weekday', 'all');
        $auth_user = Auth::user();
        $data = $this->passengerLogService->getStopMonthWeekdayInsOuts($month, $weekday);

        return view('dashboard.passenger_reports.month-weekday-ins-outs', compact(
            'data',
            'month',
            'weekday',
            'auth_user'
        ));
    }

    public function dayTotalInsOutsReporting(Request $request)
    {
        $day = $request->input('day');
        $auth_user = Auth::user();
        $data = $this->passengerLogService->getDayTotalInsOuts($day);

        return view('dashboard.passenger_reports.day-total-ins-outs', compact(
            'data',
            'day',
            'auth_user'
        ));
    }

    public function dayHourlyInsOutsReporting(Request $request)
    {
        $day = $request->input('day');
        $auth_user = Auth::user();
        $data = $this->passengerLogService->getDayHourlyInsOuts($day);

        return view('dashboard.passenger_reports.day-hourly-ins-outs', compact(
            'data',
            'day',
            'auth_user'
        ));
    }

    public function stopSixMonthInsOutsReporting(Request $request)
    {
        $stop = $request->input('stop', 'all');
        $auth_user = Auth::user();
        $stops = $this->vehicleStopService->fetch();
        $data = $this->passengerLogService->getSixMonthStopEvolution($stop);

        return view('dashboard.passenger_reports.stop-six-month-ins-outs', compact(
            'data',
            'stops',
            'stop',
            'auth_user'
        ));
    }
}
