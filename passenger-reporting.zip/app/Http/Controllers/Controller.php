<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;

abstract class Controller
{

    protected $messages;

    public function __construct() {
        $this->messages = config('messages');
    }

}
