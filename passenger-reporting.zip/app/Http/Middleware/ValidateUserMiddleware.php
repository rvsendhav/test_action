<?php

namespace App\Http\Middleware;

use App\Exceptions\CustomException;
use App\Services\UserService;
use Closure;
use Exception;
use Illuminate\Support\Facades\Config;

class ValidateUserMiddleware extends Middleware
{
    protected $userService;

    public function __construct(UserService $userService)
    {
        parent::__construct();
        $this->userService = $userService;
    }

    public function handle($request, Closure $next)
    {
        try {
            $userData = request()->input('userData');

            if (!$userData->is_email_verified) {
                throw new CustomException($this->messages["email_not_verfied"], 422, null, "auth.login");
            }

            if (!$userData->is_active) {
                throw new CustomException($this->messages["account_blocked"], 422, null, "auth.login");
            }

            return $next($request);
        } catch (Exception $e) {
            throw $e;
        }
    }
}
