<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;

class SetLocale extends Middleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Retrieve the 'Accept-Language' header from the request
        $locale = $request->header('Accept-Language');
        
        // Default to the app's locale if the header is not present
        if (!$locale) {
            $locale = config('app.locale');
        } else {
            // Extract the primary language code (e.g., 'es' from 'es-ES')
            $locale = substr($locale, 0, 2);
        }

        // Set the application locale
        App::setLocale($locale);

        return $next($request);
    }
}
