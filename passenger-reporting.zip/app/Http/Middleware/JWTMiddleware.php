<?php

namespace App\Http\Middleware;

use App\Exceptions\CustomException;
use App\Services\UserService;
use Closure;
use Exception;

class JWTMiddleware extends Middleware
{
    protected $userService;

    public function __construct(UserService $userService)
    {
        parent::__construct();
        $this->userService = $userService;
    }

    public function handle($request, Closure $next)
    {
        try {
            // Web Authentication using session
            if (!auth()->check()) {
                throw new CustomException($this->messages["token_invalid"], 401, null, "web.login.view");
            }

            $user = \Auth::user();
            if (!$user) {
                throw new CustomException($this->messages["token_invalid"], 401, null, "web.login.view");
            }

            $userData = $this->userService->fetchByEmail($user->email, [$user->user_type]);
            $request->merge([
                'authTokenData' => $user,
                'userData' => $userData,
            ]);
            view()->share('userData', $userData);
            return $next($request);
        } catch (Exception $e) {
            if ($e->getMessage()) {
                throw new CustomException($e->getMessage(), 401, [], "web.login.view");
            } else {
                throw new CustomException($this->messages["token_absent"], 401, [], "web.login.view");
            }
        }
    }
}
