<?php

namespace App\Http\Middleware;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;

abstract class Middleware
{
    protected $messages;

    public function __construct() {
        $this->messages = config('messages');
    }

}
