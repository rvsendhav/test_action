<html xmlns="http://www.w3.org/1999/xhtml" style="font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6; margin: 0; padding: 0;">

<head>
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>{{ $subject }}</title>
    <style>
        p {
            font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
            font-size: 14px;
            line-height: 1.6;
            font-weight: normal;
            margin: 0 0 10px;
            padding: 0;
        }
    </style>
</head>


<body bgcolor="#f6f6f6" style="font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6; -webkit-font-smoothing: antialiased; -webkit-text-size-adjust: none; width: 100% !important; height: 100%; margin: 0; padding: 0;">
    <script src="https://use.fontawesome.com/b40b579f97.js"></script>
    <table class="body-wrap" style="font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6; width: 100%; margin: 0; padding: 20px;">
        <tbody>
            <tr style="font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6; margin: 0; padding: 0;">
                <td class="container" bgcolor="#FFFFFF" style="font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6; display: block !important; max-width: 600px !important; clear: both !important; margin: 0 auto; padding: 0; border: 1px solid #f0f0f0;">

                    <table style="border:none;border-spacing:0;width:100%" cellspacing="0" cellpadding="0" border="0">
                        <tbody>
                            <tr>
                                <td style="background: #e6e6e6de;padding-top:15px;padding-bottom:10px;text-align: center;background-size:cover;background-image:none;vertical-align: middle;">
                                    <p style="font-size: 16px;font-weight: 700;">
                                    Terminal App
                                    </p>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <div class="content" style="font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6; max-width: 600px; display: block; margin: 0 auto; padding: 20px;">
                        <table style="font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6; width: 100%; margin: 0; padding: 0;">
                            <tbody>
                                <tr style="font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6; margin: 0; padding: 0;">
                                    <td style="font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 1.6; margin: 0; padding: 0;">
                                        <div>
                                            <p>Hello <strong>{{ $email_data['name'] }}</strong>,</p>
                                            <p>You recently requested a verify email for your Terminal account. To
                                                complete the process, click the link below:</p>
                                            <p><a href="{{ $email_data['verify_link'] }}"
                                                    style="color: #3498db;">Verify Link</a></p>
                                            <p>If you did not part of Terminal APP, please ignore this email.</p>
                                            <p>Thank you!</p>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <table style="border:none;border-spacing:0;width:100%" cellspacing="0" cellpadding="0" border="0">
                        <tbody>
                            <tr>
                                <td style="background: #60c3cc;padding: 10px;background-size:cover;background-image:none;text-align: center;">
                                    <p style="font-size: 14px;color: #FFF;margin: 0;padding: 0;">© TERMINAL 2024. ALL RIGHTS RESERVED.</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </td>
            </tr>
        </tbody>
    </table>

</body>

</html>