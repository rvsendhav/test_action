@extends('auth.layouts.app')

@section('title', 'Email Verification')

@section('content')
<div class="content-wrapper d-flex align-items-center auth px-0">
    <div class="row w-100 mx-0">
        <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
                <div class="brand-logo text-center">
                    <img src="{{ asset('assets/images/logo.png') }}" alt="logo" />
                </div>
                <h6 class="font-weight-light text-center">Email Verification</h6>

                @if (isset($message))
                    <div class="alert alert-info" id="alert-message">
                        {{ $message }}
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection
