@extends('auth.layouts.app')

@section('title', 'Login')

@section('content')
<div class="content-wrapper d-flex align-items-center auth px-0">
    <div class="row w-100 mx-0">
        <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
                <div class="brand-logo text-center">
                    <img src="{{ asset('assets/images/logo.png') }}" alt="logo" />
                </div>
                <h6 class="font-weight-light text-center">{{ __('messages.admin_dashboard.signin') }}</h6>

                <form class="pt-3" action="{{ route('web.login.post') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <input type="email" class="form-control form-control-lg" id="email" name="email" placeholder="{{ __('messages.admin_dashboard.email_address') }}">
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control form-control-lg" id="password" name="password" placeholder="{{ __('messages.admin_dashboard.password') }}">
                    </div>
                    <div class="mt-3 d-grid gap-2">
                        <button class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" type="submit" name="submit" id="submit">{{ __('messages.admin_dashboard.signin_btn') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- content-wrapper ends -->
@endsection