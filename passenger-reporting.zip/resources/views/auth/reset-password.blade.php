@extends('auth.layouts.app')

@section('title', 'Reset Password')

@section('content')
<div class="content-wrapper d-flex align-items-center auth px-0">
    <div class="row w-100 mx-0">
        <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
                <div class="brand-logo text-center">
                    <img src="{{ asset('assets/images/logo.png') }}" alt="logo" />
                </div>
                <h6 class="font-weight-light text-center">{{ __('messages.admin_dashboard.reset_password') }}</h6>
         

            <form class="pt-3" action="{{ route('web.update-password') }}" method="POST">
                @csrf
                <div class="form-group">
                    <input type="email" class="form-control form-control-lg" id="email" name="email" value="{{ $email }}" placeholder="{{ __('messages.admin_dashboard.email_address') }}" readonly>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control form-control-lg" id="password" name="password" placeholder="{{ __('messages.admin_dashboard.new_password') }}" required>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control form-control-lg" id="password_confirmation" name="password_confirmation" placeholder="{{ __('messages.admin_dashboard.confirm_password') }}" required>
                </div>
                <input type="hidden" name="token" value="{{ $token }}">
                <div class="mt-3 d-grid gap-2">
                    <button class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" type="submit">{{ __('messages.admin_dashboard.submit') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Hide messages after 5 seconds
        setTimeout(function() {
            $('#alert-error').fadeOut();
            $('#alert-success').fadeOut();
            $('#alert-errors').fadeOut();
        }, 5000); // Adjust the time (5000 ms = 5 seconds) as needed
    });

    function validatePassword() {
        var password = document.getElementById("password").value;
        var confirm_password = document.getElementById("confirm_password").value;

        if (password != confirm_password) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
    }
</script>

@endsection