<!-- partial:partials/_footer.html -->
<!--
<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © {{ date('Y') }}. <a href="" target="_blank">Terminal App</a>. All rights reserved.</span>
        <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Made by <a href="https://encoresky.com" target="_blank">EncoreSky</a></span>
    </div>
</footer>
-->