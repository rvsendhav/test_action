<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>@yield('title', 'Terminal Admin') | Terminal Admin</title>
  <link rel="shortcut icon" href="{{ asset('assets/images/logo.png') }}" type="image/x-icon">
  <!-- plugins:css -->
  <link rel="stylesheet" href="{{ asset('assets/vendors/feather/feather.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/vendors/ti-icons/css/themify-icons.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/vendors/css/vendor.bundle.base.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/vendors/font-awesome/css/font-awesome.min.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/vendors/mdi/css/materialdesignicons.min.css') }}">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <!-- <link rel="stylesheet" href="{{ asset('assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css') }}"> -->
  <!-- <link rel="stylesheet" href="{{ asset('assets/vendors/datatables.net-bs5/dataTables.bootstrap5.css') }}"> -->
  <link rel="stylesheet" href="{{ asset('assets/vendors/ti-icons/css/themify-icons.css') }}">
  <!-- <link rel="stylesheet" type="text/css" href="{{ asset('assets/js/select.dataTables.min.css') }}"> -->
  <!-- <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/2.1.4/css/dataTables.dataTables.min.css" /> -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">

  <link href="{{ asset('assets/css/bootstrap-toggle.min.css') }}" rel="stylesheet">
  <!-- End plugin css for this page -->
  
  <!-- Date and Time picker -->
  <link rel="stylesheet" href="{{ asset('css/bootstrap-datepicker.standalone.min.css') }}">
  <link rel="stylesheet" href="{{ asset('css/bootstrap-timepicker.min.css') }}">

  <!-- inject:css -->
  <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/css/custom.css') }}">
  <!-- endinject -->
  <meta name="csrf-token" content="{{ csrf_token() }}">
</head>

<body>
  <div class="container-scroller">

    @include('dashboard.layouts.header')
        <div class="row notification-container end-0 top-0">
            <div id="notification-container" class="col-lg-12 end-0 top-0">

            </div>
        </div>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">

      @include('dashboard.layouts.sidebar')

      <div class="main-panel">
  
        @yield('content')

        @include('dashboard.layouts.footer')

        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="{{ asset('assets/vendors/js/vendor.bundle.base.js') }}"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <!-- <script src="{{ asset('assets/vendors/chart.js/chart.umd.js') }}"></script> -->
  <!-- <script src="{{ asset('assets/vendors/datatables.net/jquery.dataTables.js') }}"></script> -->
  <!-- <script src="{{ asset('assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js') }}"></script> -->
  <!-- <script src="{{ asset('assets/vendors/datatables.net-bs5/dataTables.bootstrap5.js') }}"></script> -->
  <!-- <script src="//cdn.datatables.net/2.1.4/js/dataTables.min.js"></script> -->
  <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

  <script src="{{ asset('assets/js/dataTables.select.min.js') }}"></script>

  <script src="{{ asset('assets/js/bootstrap-toggle.min.js') }}"></script>
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="{{ asset('assets/js/off-canvas.js') }}"></script>
  <script src="{{ asset('assets/js/template.js') }}"></script>
  <script src="{{ asset('assets/js/settings.js') }}"></script>
  <script src="{{ asset('assets/js/todolist.js') }}"></script>
  <script src="{{ asset('assets/js/data-table.js') }}"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="{{ asset('assets/js/jquery.cookie.js') }}" type="text/javascript"></script>
  <script src="{{ asset('assets/js/dashboard.js') }}"></script>
  <!-- <script src="{{ asset('assets/js/Chart.roundedBarCharts.js') }}"></script> -->
  <script src="{{ asset('js/bootstrap-datepicker.min.js') }}"></script>
  <script src="{{ asset('js/bootstrap-timepicker.min.js') }}"></script>
  <script src="{{ asset('assets/js/custom.js') }}"></script>
  <script src="{{ asset('assets/vendors/chart.js/chart.umd.js') }}"></script>
  <!-- End custom js for this page-->
  <script type="text/javascript">
    var BASE_URL = "{{ config('constants.APP_URL') }}";
  </script>
</body>
@if (session('success'))
    <script>
        $(document).ready(function(){
            // Create a success message element
            var successMessage = $('<div class="alert alert-success end-0 top-0">').text('{{ session('success') }}');

            // Append the success message to the container
            $('#notification-container').append(successMessage);

            // Automatically remove the success message after 3 seconds
            setTimeout(function(){
                successMessage.remove();
            }, 3000);
        });
    </script>
@endif

@if (session('error'))
    <script>
        $(document).ready(function(){
            // Create an error message element
            var errorMessage = $('<div class="alert alert-danger end-0 top-0">').text('{{ session('error') }}');

            // Append the error message to the container
            $('#notification-container').append(errorMessage);

            // Automatically remove the error message after 3 seconds
            setTimeout(function(){
                errorMessage.remove();
            }, 3000);
        });
    </script>
@endif
</html>