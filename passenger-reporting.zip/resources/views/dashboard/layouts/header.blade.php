<!-- partial:partials/_navbar.html -->
<nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
    <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-start">
        <a class="navbar-brand brand-logo me-5" href="">
            <img src="{{ asset('assets/images/logo.png') }}" alt="logo" />
        </a>
        <a class="navbar-brand brand-logo-mini" href="">
            <img src="{{ asset('assets/images/logo.png') }}" alt="logo" />
        </a>
    </div>
    <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item">
                <div class="fw-bold">
                    {{ __('messages.admin_dashboard.welcome') }} {{ $auth_user->name }}
                </div>
            </li>
            <li class="nav-item nav-profile dropdown">
                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                    <img src="{{ asset('assets/images/faces/avatar.webp') }}" alt="profile" />
                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">

                    @if(isset($auth_user) && $auth_user)
                    <a class="dropdown-item" href="mailto: {{ $auth_user->email }}">
                        <i class="mdi mdi-email text-primary"></i> {{ $auth_user->email }}
                    </a>
                    @endif

                    <a class="dropdown-item" href="{{ route('web.dashboard.profile') }}">
                        <i class="mdi mdi-account-circle text-primary"></i> {{ __('messages.admin_dashboard.profile') }}
                    </a>
                    <a class="dropdown-item" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="ti-power-off text-danger"></i> <span class="text-danger">{{ __('messages.admin_dashboard.logout') }}</span>
                    </a>
                </div>
            </li>
        </ul>

        <form id="logout-form" action="{{ route('web.logout') }}" method="POST" style="display: none;">
            @csrf
        </form>

        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="icon-menu"></span>
        </button>
    </div>
</nav>