@extends('dashboard.layouts.app')

@section('title', 'Add New Vehicle')

@section('content')

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-8">
                            <h4 class="card-title">Add New Vehicle</h4>
                        </div>
                        <div class="col-lg-4">
                            <a href="{{ route('vehicle-settings.index') }}" class="btn btn-primary btn-sm pull-right">Back</a>
                        </div>
                    </div>
            
                    <div class="row">
                        <div class="col-lg-12">
                            <form class="forms-sample" action="{{ route('vehicle-settings.store') }}" method="POST">
                                @csrf
                                <div class="form-group row">
                                    <div class="col">
                                        <label for="name">Name</label>
                                        <div id="the-basics">
                                            <input type="text" class="form-control form-control-sm" id="name" name="name"" value="{{ old('name') }}" placeholder="Name" required>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary me-2">Save</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

@endsection