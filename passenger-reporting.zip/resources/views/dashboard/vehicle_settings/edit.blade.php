@extends('dashboard.layouts.app')

@section('title', 'Edit Vehicle')

@section('content')

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-8">
                            <h4 class="card-title">Edit Name: {{ $vehicle_setting->name }}</h4>
                        </div>
                        <div class="col-lg-4">
                            <a href="{{ route('vehicle-settings.index') }}" class="btn btn-primary btn-sm pull-right">Back</a>
                        </div>
                    </div>
           
                    <div class="row">
                        <div class="col-lg-12">
                            <form class="forms-sample" action="{{ route('vehicle-settings.update', $vehicle_setting->id) }}" method="POST">
                                @csrf
                                @method('PUT')
                                <div class="form-group row">
                                    <div class="col">
                                        <label for="name">Name</label>
                                        <div id="the-basics">
                                            <input type="text" class="form-control form-control-sm" id="name" name="name"" value="{{ $vehicle_setting->name }}" placeholder="Name shown on page" required>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary me-2">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

@endsection