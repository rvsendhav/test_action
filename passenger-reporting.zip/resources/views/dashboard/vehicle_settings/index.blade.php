@extends('dashboard.layouts.app')

@section('title', 'Vehicles')

@section('content')

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <h4 class="card-title">
                                Vehicles ({{ $total_vehicle_settings }})
                            </h4>
                        </div>
                        <div class="col-lg-4">
                            <form class="forms-sample" action="{{ route('vehicle-settings.index') }}" method="GET">
                                <div class="form-group">
                                    <div class="input-group d-flex align-items-center">
                                        <input type="text" class="form-control form-control-sm" value="{{ $search ?? '' }}" placeholder="Search" aria-label="Search" name="search">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary btn-md ms-2" type="submit">Search</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-4 text-right">
                            <a class="btn btn-primary" href="{{ route('vehicle-settings.create') }}">Add New</a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <hr />
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if(isset($vehicle_settings) && sizeof($vehicle_settings))
                                        @foreach( $vehicle_settings AS $key => $vehicle_setting)
                                        <tr>
                                            <td>{{ $vehicle_setting->name ?? '-' }}</td>
                                            <td>
                                                @if($vehicle_setting->is_active)
                                                <input type="checkbox" class="is_active" checked data-toggle="toggle" data-size="mini" data-onstyle="success" data-offstyle="danger" data-on="Show" data-off="Hide" data-id="{{ $vehicle_setting->id }}" data-action_type="vehicle-settings">
                                                @else
                                                <input type="checkbox" class="is_active" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-size="mini" data-on="Show" data-off="Hide" data-id="{{ $vehicle_setting->id }}" data-action_type="vehicle-settings">
                                                @endif
                                            </td>
                                            <td>
                                                <a class="btn btn-primary btn-xs" href="{{ route('vehicle-settings.edit', $vehicle_setting->id) }}">Edit</a>
                                            </td>
                                        </tr>
                                        @endforeach
                                        @else
                                        <tr>
                                            <td colspan="3">No Record Found</td>
                                        </tr>
                                        @endif
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Name</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="pagination">
                                {{ $vehicle_settings->links("pagination::bootstrap-5") }}
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

@endsection