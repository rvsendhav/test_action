@extends('dashboard.layouts.app')

@section('title', 'Edit Vehicle Stop')

@section('content')

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-8">
                            <h4 class="card-title">Edit Name: {{ $vehicle_stop->name }}</h4>
                        </div>
                        <div class="col-lg-4">
                            <a href="{{ route('vehicle-stops.index') }}" class="btn btn-primary btn-sm pull-right">Back</a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <form class="forms-sample" action="{{ route('vehicle-stops.update', $vehicle_stop->id) }}" method="POST">
                                @csrf
                                @method('PUT')
                                <div class="form-group row">
                                    <div class="col">
                                        <label for="name">Name</label>
                                        <div id="the-basics">
                                            <input type="text" class="form-control form-control-sm" id="name" name="name"" value="{{ $vehicle_stop->name }}" placeholder="Name shown on page" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col">
                                        <label for="latitude">Latitude</label>
                                        <div id="the-basics">
                                            <input type="number" step="0.0000001" min="-90" max="90" class="form-control form-control-sm" id="latitude" name="latitude"" value="{{ $vehicle_stop->latitude }}" placeholder="Latitude" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col">
                                        <label for="longitude">longitude</label>
                                        <div id="the-basics">
                                            <input type="number" step="0.0000001" min="-180" max="180" class="form-control form-control-sm" id="longitude" name="longitude"" value="{{ $vehicle_stop->longitude }}" placeholder="Longitude">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col">
                                        <label for="address">Address</label>
                                        <div id="the-basics">
                                            <input type="text" class="form-control form-control-sm" id="address" name="address"" value="{{ $vehicle_stop->address }}" placeholder="address">
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary me-2">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

@endsection