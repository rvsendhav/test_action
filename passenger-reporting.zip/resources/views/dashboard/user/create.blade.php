@extends('dashboard.layouts.app')

@section('title', 'Add New User')

@section('content')

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-8">
                            <h4 class="card-title">Add New User</h4>
                        </div>
                        <div class="col-lg-4">
                            <a href="{{ route('users.index') }}" class="btn btn-primary btn-sm pull-right">Back</a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <form class="forms-sample" action="{{ route('users.store') }}" method="POST">
                                @csrf
                                <div class="form-group row">
                                    <div class="col">
                                        <label for="name">Name</label>
                                        <div id="the-basics">
                                            <input type="text" class="form-control form-control-sm" id="name" name="name"" value="{{ old('name') }}" placeholder="Name" required>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <label for="email">Email</label>
                                        <input type="email" class="form-control form-control-sm" id="email" name="email"" value="{{ old('email') }}" placeholder="Email Address" required>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col">
                                        <label for="new_password">Password</label>
                                        <div id="bloodhound">
                                            <input type="password" class="form-control form-control-sm" id="new_password" name="new_password"" value="{{ old('new_password') }}" placeholder="Password" required>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <label for="new_password_confirmation">Confirm Password</label>
                                        <div id="bloodhound">
                                            <input type="password" class="form-control form-control-sm" id="new_password_confirmation" name="new_password_confirmation"" value="{{ old('new_password_confirmation') }}" placeholder="Confirm Password" required>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary me-2">Save</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

@endsection