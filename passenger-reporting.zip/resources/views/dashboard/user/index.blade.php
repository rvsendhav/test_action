@extends('dashboard.layouts.app')

@section('title', 'Users')

@section('content')

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <h4 class="card-title">
                                Users ({{ $total_users }})
                            </h4>
                        </div>
                        <div class="col-lg-4">
                            <form class="forms-sample" action="{{ route('users.index') }}" method="GET">
                                <div class="form-group">
                                    <div class="input-group d-flex align-items-center">
                                        <input type="text" class="form-control form-control-sm" value="{{ $search ?? '' }}" placeholder="Search" aria-label="Search" name="search">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary btn-md ms-2" type="submit">Search</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-2">
                            <a class="btn btn-primary pull-right" href="{{ route('users.create') }}">Add New</a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <hr/>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if(isset($users) && sizeof($users))
                                        @foreach( $users AS $key => $user)
                                        <tr>
                                            <td>
                                                @if( $user->image )
                                                    <img src="{{ url(Storage::url($user->image)) }}" alt="{{ $user->name }}" width="100" height="100" />
                                                @else
                                                    <img src="{{ asset('assets/images/faces/avatar.webp') }}" alt="{{ $user->name }}" width="100" height="100" />
                                                @endif
                                            </td>
                                            <td>{{ $user->name }}</td>
                                            <td>{{ $user->email }}</td>
                                            <td>
                                                @if( $user->user_type !== 'Admin' && $user->id !== $auth_user->id )
                                                @if($user->is_active)
                                                <input type="checkbox" class="is_active" checked data-toggle="toggle" data-size="mini" data-onstyle="success" data-offstyle="danger" data-on="Active" data-off="Inactive" data-id="{{ $user->id }}" data-action_type="users">
                                                @else
                                                <input type="checkbox" class="is_active" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-size="mini" data-on="Active" data-off="Inactive" data-id="{{ $user->id }}" data-action_type="users">
                                                @endif
                                                @else
                                                @if($user->is_active)
                                                <label class="badge badge-success">Active</label>
                                                @else
                                                <label class="badge badge-warning">Inactive</label>
                                                @endif
                                                @endif
                                            </td>
                                            <td>
                                                @if( $user->id !== $auth_user->id )
                                                <a class="btn btn-primary btn-xs" href="{{ route('users.edit', $user->id) }}">Edit</a>
                                                @endif
                                                
                                                @if( $user->id !== $auth_user->id )
                                                <a class="btn btn-primary btn-xs" href="{{ route('users.reset.password', $user->id) }}">Reset Password</a>
                                                @endif

                                                @if( $user->id !== $auth_user->id )
                                                <br/><br/>
                                                <form action="{{ route('users.destroy', $user->id) }}" method="POST" onsubmit="return confirmDelete()">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-xs">Delete</button>
                                                </form>
                                                @endif
                                            </td>
                                        </tr>
                                        @endforeach
                                        @else
                                        <tr>
                                            <td colspan="6">No Record Found</td>
                                        </tr>
                                        @endif
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="pagination">
                                {{ $users->links("pagination::bootstrap-5") }}
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

@endsection