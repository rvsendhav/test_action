@extends('dashboard.layouts.app')

@section('title', 'Dashboard')

@section('content')
<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-header">
                    <h3>Transit Flow Analytics: 6-Month Trend</h3>
                </div>
                <div class="card-body">
                    <form id="detailedReportingFilters" method="GET" action="{{ route('web.stop.six.month.ins.outs.view') }}">
                        <div class="row align-items-center">
                            <div class="col-md-3">
                                <label>Stop</label>
                                <select name="stop" class="form-select form-select-lg">
                                    <option value="all">Select Stop</option>
                                    @foreach($stops as $s)
                                    <option value="{{ $s->id }}" {{ $stop == $s->id ? 'selected' : '' }}>
                                        {{ $s->name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-3">
                                <br />
                                <button type="submit" class="btn btn-primary">Apply Filters</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    <canvas id="barChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const data = <?php echo json_encode($data); ?>;
        if (data) {
            var dataCtx = document.getElementById('barChart').getContext('2d');
            new Chart(dataCtx, {
                type: 'bar',
                data: {
                    labels: data.map(x => x.label),
                    datasets: [{
                            label: 'Passengers In',
                            data: data.map(x => x.total_in),
                            backgroundColor: 'rgba(34, 139, 34, 0.6)'
                        },
                        {
                            label: 'Passengers Out',
                            data: data.map(x => x.total_out),
                            backgroundColor: 'rgba(223, 12, 33, 0.6)'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
    });
</script>
@endsection