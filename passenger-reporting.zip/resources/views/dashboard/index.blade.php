@extends('dashboard.layouts.app')

@section('title', 'Dashboard')

@section('content')

<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12 grid-margin">
            <div class="row">
                <div class="col-12 col-xl-12 mb-12 mb-xl-0">
                    <h3 class="font-weight-bold">{{ __('messages.admin_dashboard.welcome') }} {{ $auth_user->name }}</h3>
                    <h6 class="font-weight-normal mb-0">{{ __('messages.admin_dashboard.all_system') }}</h6>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card tale-bg">
                <div class="card-people mt-auto">
                    <img src="assets/images/dashboard/people.svg" alt="people">
                </div>
            </div>
        </div>
        <div class="col-md-6 grid-margin transparent">
            <div class="row">
                <div class="col-md-6 mb-4 stretch-card transparent">
                    <div class="card card-tale">
                        <div class="card-body">
                            <p class="mb-4">{{ "Users" }}</p><br/>
                            <p class="fs-30 mb-2">{{ $total_users }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4 stretch-card transparent">
                    <div class="card card-dark-blue">
                        <div class="card-body">
                            <p class="mb-4">{{ "Vehicles" }}</p><br/>
                            <p class="fs-30 mb-2">{{ $total_vehicle_settings }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4 stretch-card transparent">
                    <div class="card card-light-blue">
                        <div class="card-body">
                            <p class="mb-4">{{ "Stops" }}</p><br/>
                            <p class="fs-30 mb-2">{{ $total_vehicle_stops }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4 stretch-card transparent">
                    <div class="card card-tale">
                        <div class="card-body">
                            <p class="mb-4">{{ "Passenger Logs" }}</p><br/>
                            <p class="fs-30 mb-2">{{ $total_passenger_logs }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>    
</div>
<!-- content-wrapper ends -->

@endsection