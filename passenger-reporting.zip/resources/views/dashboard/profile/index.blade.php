@extends('dashboard.layouts.app')

@section('title', 'Profile')

@section('content')

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-8">
                            <h4 class="card-title">Profile</h4>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <form class="forms-sample" action="{{ route('web.dashboard.profile.update') }}" method="POST">
                                @csrf
                                @method('PUT')
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" class="form-control form-control-sm" id="name" name="name" value="{{ $user->name }}" placeholder="First Name">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email Address</label>
                                    <input type="email" readonly class="form-control form-control-sm" id="email" name="email" value="{{ $user->email }}" placeholder="Email Address">
                                </div>
                                <button type="submit" class="btn btn-primary me-2">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

@endsection