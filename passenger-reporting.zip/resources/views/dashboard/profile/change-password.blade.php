@extends('dashboard.layouts.app')

@section('title', 'Change Password')

@section('content')

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <h4 class="card-title">Change Password</h4>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <form class="forms-sample" action="{{ route('web.dashboard.update-password') }}" method="POST">
                                @csrf
                                @method('PUT')
                                <div class="form-group">
                                    <label for="old_password">Old Password</label>
                                    <input type="password" class="form-control form-control-sm" id="old_password" name="old_password"" placeholder="Old Password">
                                </div>
                                <div class="form-group">
                                    <label for="new_password">New Password</label>
                                    <input type="password" class="form-control form-control-sm" id="new_password" name="new_password"" placeholder="New Password">
                                </div>
                                <div class="form-group">
                                    <label for="new_password_confirmation">Confirm Password</label>
                                    <input type="password" class="form-control form-control-sm" id="new_password_confirmation" name="new_password_confirmation"" placeholder="Confirm Password">
                                </div>
                                <button type="submit" class="btn btn-primary me-2">Change</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

@endsection