@extends('dashboard.layouts.app')

@section('title', 'Vehicle Stop Reports')

@section('content')

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <h4 class="card-title">
                               Passenger Logs ({{ $total_passenger_logs }})
                            </h4>
                        </div>
                        <div class="col-lg-4">
                            <form class="forms-sample" action="{{ route('passenger-logs.index') }}" method="GET">
                                <div class="form-group">
                                    <div class="input-group d-flex align-items-center">
                                        <input type="text" class="form-control form-control-sm" value="{{ $search ?? '' }}" placeholder="Search" aria-label="Search" name="search">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary btn-md ms-2" type="submit">Search</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-4 text-right">
                            <a class="btn btn-primary" href="{{ route('passenger-logs.create') }}">Upload New</a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <hr/>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Stop Name</th>
                                            <th>Vehicle Name</th>
                                            <th>Log Date</th>
                                            <th>Direction</th>
                                            <th>Latitude</th>
                                            <th>Longitude</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if(isset($passenger_logs) && sizeof($passenger_logs))
                                        @foreach( $passenger_logs AS $key => $passenger_log)
                                        <tr>
                                            <td>{{ $passenger_log->stop->name ?? '-' }}</td>
                                            <td>{{ $passenger_log->vehicle->name ?? '-' }}</td>
                                            <td>{{ $passenger_log->log_date ?? '-' }}</td>
                                            <td>{{ $passenger_log->direction ?? '-' }}</td>
                                            <td>{{ $passenger_log->latitude ?? '-' }}</td>
                                            <td>{{ $passenger_log->longitude ?? '-' }}</td>
                                        </tr>
                                        @endforeach
                                        @else
                                        <tr>
                                            <td colspan="5">No Record Found</td>
                                        </tr>
                                        @endif
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Stop Name</th>
                                            <th>Vehicle Name</th>
                                            <th>Log Date</th>
                                            <th>Direction</th>
                                            <th>Latitude</th>
                                            <th>Longitude</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="pagination">
                                {{ $passenger_logs->links("pagination::bootstrap-5") }}
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

@endsection