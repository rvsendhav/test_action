@extends('dashboard.layouts.app')

@section('title', 'Upload Vehicle Stop Report')

@section('content')

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-8">
                            <h4 class="card-title">Upload Vehicle Stop Report</h4>
                        </div>
                        <div class="col-lg-4">
                            <a href="{{ route('passenger-logs.index') }}" class="btn btn-primary btn-sm pull-right">Back</a>
                        </div>
                    </div>
                  
                    <div class="row">
                        <div class="col-lg-4">
                            <form class="forms-sample" action="{{ route('passenger-logs.store') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="form-group row">
                                    <div class="col">
                                        <label for="file">Upload XLSX File</label>
                                        <div id="the-basics">
                                            <input type="file" class="form-control form-control-lg" id="file" name="file" accept=".xlsx" required>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary me-2">Upload</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

@endsection