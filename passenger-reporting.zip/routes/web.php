<?php

use App\Http\Controllers\Web\AuthController;
use App\Http\Controllers\Web\DashboardController;
use App\Http\Controllers\Web\PassengerLogController;
use App\Http\Controllers\Web\UserController;
use App\Http\Controllers\Web\UsersController;
use App\Http\Controllers\Web\VehicleSettingsController;
use App\Http\Controllers\Web\VehicleStopsController;
use App\Http\Middleware\JWTMiddleware;
use Illuminate\Support\Facades\Route;
use App\Http\Middleware\SetLocale;

Route::middleware([SetLocale::class])->group(function () {
Route::get('page-not-found', [AuthController::class, 'pageNotFound'])->name('web.page_not_found');
Route::get('unauthorized-access', [AuthController::class, 'unauthorizedAccess'])->name('web.unauthorized_access');

Route::get('/', [AuthController::class, 'index'])->name('web.login.view');
Route::post('/login', [AuthController::class, 'loginPost'])->name('web.login.post');
Route::get('/reset-password/{token}', [AuthController::class, 'resetPassword'])->name('web.reset-password');
Route::get('/verify/email/{token}', [AuthController::class, 'verifyEmail'])->name('web.verify.email');
Route::post('/reset-password', [AuthController::class, 'updatePassword'])->name('web.update-password');

Route::middleware([JWTMiddleware::class])->group(function () {
    Route::get('dashboard', [DashboardController::class, 'index'])->name('web.dashboard.view');
    Route::get('reporting/day-total-ins-outs', [DashboardController::class, 'dayTotalInsOutsReporting'])->name('web.day.total.ins.outs.view');
    Route::get('reporting/day-hourly-ins-outs', [DashboardController::class, 'dayHourlyInsOutsReporting'])->name('web.day.hourly.ins.outs.view');
    Route::get('reporting/month-weekday-ins-outs', [DashboardController::class, 'stopMonthWeekdayInsOutsReporting'])->name('web.month.weekday.ins.outs.view');
    Route::get('reporting/stop-total-ins-outs', [DashboardController::class, 'stopTotalInsOutsReporting'])->name('web.stop.total.ins.outs.view');
    Route::get('reporting/stop-monthly-daily-ins-outs', [DashboardController::class, 'stopMonthlyDailyInsOutsReporting'])->name('web.stop.monthly.daily.ins.outs.view');
    Route::get('reporting/stop-six-month-ins-outs', [DashboardController::class, 'stopSixMonthInsOutsReporting'])->name('web.stop.six.month.ins.outs.view');
    Route::get('reporting/vehicle-monthly-ins-outs', [DashboardController::class, 'vehicleMonthlyInsOutsReporting'])->name('web.vehicle.monthly.ins.outs.view');
    Route::post('logout', [UserController::class, 'logout'])->name('web.logout');

    // User Settings
    Route::get('/profile', [UserController::class, 'index'])->name('web.dashboard.profile');
    Route::put('/profile/update', [UserController::class, 'updateProfile'])->name('web.dashboard.profile.update');
    Route::get('/change-password', [UserController::class, 'changePassword'])->name('web.dashboard.change-password');
    Route::put('/update-password', [UserController::class, 'updatePassword'])->name('web.dashboard.update-password');

    // Users
    Route::resource('users', UsersController::class);
    Route::put('users/status/{id}/update', [UsersController::class, 'updateStatus'])->name('web.dashboard.users.status');
    Route::get('users/{id}/reset/password', [UsersController::class, 'resetPassword'])->name('users.reset.password');
    Route::put('users/{id}/reset/password/link', [UsersController::class, 'sendResetPasswordLink'])->name('users.reset.password.link');

    Route::resource('vehicle-stops', VehicleStopsController::class);
    Route::put('vehicle-stops/status/{id}/update', [VehicleStopsController::class, 'updateStatus'])->name('web.dashboard.vehicle_stops.status');

    Route::resource('vehicle-settings', VehicleSettingsController::class);
    Route::put('vehicle-settings/status/{id}/update', [VehicleSettingsController::class, 'updateStatus'])->name('web.dashboard.vehicle_settings.status');

    Route::resource('passenger-logs', PassengerLogController::class);

});
});
