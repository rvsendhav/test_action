(function ($) {
    "use strict";
    $(function () {
        // $("#country-listing").DataTable({
        //     aLengthMenu: [
        //         [5, 10, 15, -1],
        //         [5, 10, 15, "All"],
        //     ],
        //     iDisplayLength: 10,
        //     language: {
        //         search: "",
        //     },
        // });
        // $("#country-listing").each(function () {
        //     var datatable = $(this);
        //     // SEARCH - Add the placeholder for Search and Turn this into in-line form control
        //     var search_input = datatable
        //         .closest(".dataTables_wrapper")
        //         .find("div[id$=_filter] input");
        //     search_input.attr("placeholder", "Search");
        //     search_input.removeClass("form-control-sm");
        //     // LENGTH - Inline-Form control
        //     var length_sel = datatable
        //         .closest(".dataTables_wrapper")
        //         .find("div[id$=_length] select");
        //     length_sel.removeClass("form-control-sm");
        // });

        // $("#category-listing").DataTable({
        //     aLengthMenu: [
        //         [5, 10, 15, -1],
        //         [5, 10, 15, "All"],
        //     ],
        //     iDisplayLength: 10,
        //     language: {
        //         search: "",
        //     },
        // });
        // $("#category-listing").each(function () {
        //     var datatable = $(this);
        //     // SEARCH - Add the placeholder for Search and Turn this into in-line form control
        //     var search_input = datatable
        //         .closest(".dataTables_wrapper")
        //         .find("div[id$=_filter] input");
        //     search_input.attr("placeholder", "Search");
        //     search_input.removeClass("form-control-sm");
        //     // LENGTH - Inline-Form control
        //     var length_sel = datatable
        //         .closest(".dataTables_wrapper")
        //         .find("div[id$=_length] select");
        //     length_sel.removeClass("form-control-sm");
        // });

        // $("#sub-category-listing").DataTable({
        //     aLengthMenu: [
        //         [5, 10, 15, -1],
        //         [5, 10, 15, "All"],
        //     ],
        //     iDisplayLength: 10,
        //     language: {
        //         search: "",
        //     },
        // });
        // $("#sub-category-listing").each(function () {
        //     var datatable = $(this);
        //     // SEARCH - Add the placeholder for Search and Turn this into in-line form control
        //     var search_input = datatable
        //         .closest(".dataTables_wrapper")
        //         .find("div[id$=_filter] input");
        //     search_input.attr("placeholder", "Search");
        //     search_input.removeClass("form-control-sm");
        //     // LENGTH - Inline-Form control
        //     var length_sel = datatable
        //         .closest(".dataTables_wrapper")
        //         .find("div[id$=_length] select");
        //     length_sel.removeClass("form-control-sm");
        // });

        // $('#users-listing').DataTable({
        //   "aLengthMenu": [
        //     [5, 10, 15, 20, 25, 30, -1],
        //     [5, 10, 15, 20, 25, 30, "All"]
        //   ],
        //   "iDisplayLength": 10
        // });
    });
})(jQuery);