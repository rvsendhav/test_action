$(function () {
    function ajaxCall(url, data, method = "POST", options = {}) {
        // Default options
        const defaults = {
            showNotification: true,
            successCallback: null,
            errorCallback: null,
            beforeSend: null,
            contentType: 'application/x-www-form-urlencoded; charset=UTF-8'
        };
    
        // Merge default options with provided options
        const settings = { ...defaults, ...options };
    
        // Show loading state if needed
        if (settings.beforeSend) {
            settings.beforeSend();
        }
    
        return $.ajax({
            url: url,
            type: method,
            data: data,
            contentType: settings.contentType,
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content")
            },
            success: function(response) {
                if (response.success) {
                    // Call success callback if provided
                    if (settings.successCallback && typeof settings.successCallback === 'function') {
                        settings.successCallback(response);
                    }
                } else {
                    
                    // Call error callback if provided
                    if (settings.errorCallback && typeof settings.errorCallback === 'function') {
                        settings.errorCallback(response);
                    }
                }
            },
            error: function(xhr, status, error) {
                let errorMessage = 'An error occurred';
                
                // Handle different types of errors
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                } else if (xhr.status === 422) { // Validation errors
                    errorMessage = Object.values(xhr.responseJSON.errors).flat().join('<br>');
                } else if (xhr.status === 419) { // CSRF token mismatch
                    errorMessage = 'Session expired. Please refresh the page.';
                } else if (xhr.status === 403) {
                    errorMessage = 'You do not have permission to perform this action.';
                } else if (xhr.status === 404) {
                    errorMessage = 'The requested resource was not found.';
                } else if (xhr.status === 500) {
                    errorMessage = 'Internal server error occurred.';
                }
                
                // Call error callback if provided
                if (settings.errorCallback && typeof settings.errorCallback === 'function') {
                    settings.errorCallback(xhr, status, error);
                }
                
                console.error('AJAX Error:', {
                    status: xhr.status,
                    statusText: xhr.statusText,
                    responseText: xhr.responseText,
                    error: error
                });
            }
        });
    }    

    $(".is_active").change(function (e) {
        e.preventDefault();
        let url =
            BASE_URL +
            "/" +
            $(this).data("action_type") +
            "/status/" +
            $(this).data("id") +
            "/update";
        let data = {
            type: "is_active",
            is_active: $(this).prop("checked") ? true : false,
        };
        ajaxCall(url, data, "PUT");
    });

    $(".status").change(function (e) {
        e.preventDefault();
        let url =
            BASE_URL +
            "/" +
            $(this).data("action_type") +
            "/status/" +
            $(this).data("id") +
            "/update";
        let data = {
            type: "status",
            status: $(this).prop("checked") ? "active" : "inactive",
        };
        ajaxCall(url, data, "PUT");
    });

    $(".service_status").change(function (e) {
        e.preventDefault();
        let url =
            BASE_URL +
            "/" +
            $(this).data("action_type") +
            "/status/" +
            $(this).data("id") +
            "/update";
        let data = {
            type: "service_status",
            status: $(this).prop("checked") ? "active" : "inactive",
        };
        ajaxCall(url, data, "PUT");
    });

    $("#start_date").datepicker({
        format: "yyyy-mm-dd",
        todayBtn: true
    });
    $("#end_date").datepicker({
        format: "yyyy-mm-dd",
        todayBtn: true
    });
    $('#start_time').timepicker({
        showMeridian: false,
    });
    $('#end_time').timepicker({
        showMeridian: false,
    });
});

function confirmDelete() {
    return confirm("Are you sure you want to delete this record?");
}