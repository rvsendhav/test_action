<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $__env->yieldContent('title', 'Terminal Admin'); ?> | Terminal Admin</title>
  <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo.png')); ?>" type="image/x-icon">
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/feather/feather.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/ti-icons/css/themify-icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/css/vendor.bundle.base.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/font-awesome/css/font-awesome.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/mdi/css/materialdesignicons.min.css')); ?>">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <!-- <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>"> -->
  <!-- <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/datatables.net-bs5/dataTables.bootstrap5.css')); ?>"> -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/ti-icons/css/themify-icons.css')); ?>">
  <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/js/select.dataTables.min.css')); ?>"> -->
  <!-- <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/2.1.4/css/dataTables.dataTables.min.css" /> -->
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">

  <link href="<?php echo e(asset('assets/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet">
  <!-- End plugin css for this page -->
  
  <!-- Date and Time picker -->
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-datepicker.standalone.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-timepicker.min.css')); ?>">

  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
  <!-- endinject -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
  <div class="container-scroller">

    <?php echo $__env->make('dashboard.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row notification-container end-0 top-0">
            <div id="notification-container" class="col-lg-12 end-0 top-0">

            </div>
        </div>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">

      <?php echo $__env->make('dashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="main-panel">
  
        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('dashboard.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="<?php echo e(asset('assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <!-- <script src="<?php echo e(asset('assets/vendors/chart.js/chart.umd.js')); ?>"></script> -->
  <!-- <script src="<?php echo e(asset('assets/vendors/datatables.net/jquery.dataTables.js')); ?>"></script> -->
  <!-- <script src="<?php echo e(asset('assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script> -->
  <!-- <script src="<?php echo e(asset('assets/vendors/datatables.net-bs5/dataTables.bootstrap5.js')); ?>"></script> -->
  <!-- <script src="//cdn.datatables.net/2.1.4/js/dataTables.min.js"></script> -->
  <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

  <script src="<?php echo e(asset('assets/js/dataTables.select.min.js')); ?>"></script>

  <script src="<?php echo e(asset('assets/js/bootstrap-toggle.min.js')); ?>"></script>
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="<?php echo e(asset('assets/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/template.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/settings.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/todolist.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/data-table.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(asset('assets/js/jquery.cookie.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('assets/js/dashboard.js')); ?>"></script>
  <!-- <script src="<?php echo e(asset('assets/js/Chart.roundedBarCharts.js')); ?>"></script> -->
  <script src="<?php echo e(asset('js/bootstrap-datepicker.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/bootstrap-timepicker.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendors/chart.js/chart.umd.js')); ?>"></script>
  <!-- End custom js for this page-->
  <script type="text/javascript">
    var BASE_URL = "<?php echo e(config('constants.APP_URL')); ?>";
  </script>
</body>
<?php if(session('success')): ?>
    <script>
        $(document).ready(function(){
            // Create a success message element
            var successMessage = $('<div class="alert alert-success end-0 top-0">').text('<?php echo e(session('success')); ?>');

            // Append the success message to the container
            $('#notification-container').append(successMessage);

            // Automatically remove the success message after 3 seconds
            setTimeout(function(){
                successMessage.remove();
            }, 3000);
        });
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <script>
        $(document).ready(function(){
            // Create an error message element
            var errorMessage = $('<div class="alert alert-danger end-0 top-0">').text('<?php echo e(session('error')); ?>');

            // Append the error message to the container
            $('#notification-container').append(errorMessage);

            // Automatically remove the error message after 3 seconds
            setTimeout(function(){
                errorMessage.remove();
            }, 3000);
        });
    </script>
<?php endif; ?>
</html><?php /**PATH /home/encoreskydev-passenger-reporting/htdocs/passenger-reporting.encoreskydev.com/resources/views/dashboard/layouts/app.blade.php ENDPATH**/ ?>