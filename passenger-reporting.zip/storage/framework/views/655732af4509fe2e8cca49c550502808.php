<?php $__env->startSection('title', 'Vehicle Stop Reports'); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <h4 class="card-title">
                               Passenger Logs (<?php echo e($total_passenger_logs); ?>)
                            </h4>
                        </div>
                        <div class="col-lg-4">
                            <form class="forms-sample" action="<?php echo e(route('passenger-logs.index')); ?>" method="GET">
                                <div class="form-group">
                                    <div class="input-group d-flex align-items-center">
                                        <input type="text" class="form-control form-control-sm" value="<?php echo e($search ?? ''); ?>" placeholder="Search" aria-label="Search" name="search">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary btn-md ms-2" type="submit">Search</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-4 text-right">
                            <a class="btn btn-primary" href="<?php echo e(route('passenger-logs.create')); ?>">Upload New</a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <hr/>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Stop Name</th>
                                            <th>Vehicle Name</th>
                                            <th>Log Date</th>
                                            <th>Direction</th>
                                            <th>Latitude</th>
                                            <th>Longitude</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(isset($passenger_logs) && sizeof($passenger_logs)): ?>
                                        <?php $__currentLoopData = $passenger_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $passenger_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($passenger_log->stop->name ?? '-'); ?></td>
                                            <td><?php echo e($passenger_log->vehicle->name ?? '-'); ?></td>
                                            <td><?php echo e($passenger_log->log_date ?? '-'); ?></td>
                                            <td><?php echo e($passenger_log->direction ?? '-'); ?></td>
                                            <td><?php echo e($passenger_log->latitude ?? '-'); ?></td>
                                            <td><?php echo e($passenger_log->longitude ?? '-'); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="5">No Record Found</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Stop Name</th>
                                            <th>Vehicle Name</th>
                                            <th>Log Date</th>
                                            <th>Direction</th>
                                            <th>Latitude</th>
                                            <th>Longitude</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="pagination">
                                <?php echo e($passenger_logs->links("pagination::bootstrap-5")); ?>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/encoreskydev-passenger-reporting/htdocs/passenger-reporting.encoreskydev.com/resources/views/dashboard/passenger_logs/index.blade.php ENDPATH**/ ?>