<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12 grid-margin">
            <div class="row">
                <div class="col-12 col-xl-12 mb-12 mb-xl-0">
                    <h3 class="font-weight-bold"><?php echo e(__('messages.admin_dashboard.welcome')); ?> <?php echo e($auth_user->name); ?></h3>
                    <h6 class="font-weight-normal mb-0"><?php echo e(__('messages.admin_dashboard.all_system')); ?></h6>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card tale-bg">
                <div class="card-people mt-auto">
                    <img src="assets/images/dashboard/people.svg" alt="people">
                </div>
            </div>
        </div>
        <div class="col-md-6 grid-margin transparent">
            <div class="row">
                <div class="col-md-6 mb-4 stretch-card transparent">
                    <div class="card card-tale">
                        <div class="card-body">
                            <p class="mb-4"><?php echo e("Users"); ?></p><br/>
                            <p class="fs-30 mb-2"><?php echo e($total_users); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4 stretch-card transparent">
                    <div class="card card-dark-blue">
                        <div class="card-body">
                            <p class="mb-4"><?php echo e("Vehicles"); ?></p><br/>
                            <p class="fs-30 mb-2"><?php echo e($total_vehicle_settings); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4 stretch-card transparent">
                    <div class="card card-light-blue">
                        <div class="card-body">
                            <p class="mb-4"><?php echo e("Stops"); ?></p><br/>
                            <p class="fs-30 mb-2"><?php echo e($total_vehicle_stops); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4 stretch-card transparent">
                    <div class="card card-tale">
                        <div class="card-body">
                            <p class="mb-4"><?php echo e("Passenger Logs"); ?></p><br/>
                            <p class="fs-30 mb-2"><?php echo e($total_passenger_logs); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>    
</div>
<!-- content-wrapper ends -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/encoreskydev-passenger-reporting/htdocs/passenger-reporting.encoreskydev.com/resources/views/dashboard/index.blade.php ENDPATH**/ ?>