<?php $__env->startSection('title', 'Vehicles'); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <h4 class="card-title">
                                Vehicles (<?php echo e($total_vehicle_settings); ?>)
                            </h4>
                        </div>
                        <div class="col-lg-4">
                            <form class="forms-sample" action="<?php echo e(route('vehicle-settings.index')); ?>" method="GET">
                                <div class="form-group">
                                    <div class="input-group d-flex align-items-center">
                                        <input type="text" class="form-control form-control-sm" value="<?php echo e($search ?? ''); ?>" placeholder="Search" aria-label="Search" name="search">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary btn-md ms-2" type="submit">Search</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-4 text-right">
                            <a class="btn btn-primary" href="<?php echo e(route('vehicle-settings.create')); ?>">Add New</a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <hr />
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(isset($vehicle_settings) && sizeof($vehicle_settings)): ?>
                                        <?php $__currentLoopData = $vehicle_settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vehicle_setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($vehicle_setting->name ?? '-'); ?></td>
                                            <td>
                                                <?php if($vehicle_setting->is_active): ?>
                                                <input type="checkbox" class="is_active" checked data-toggle="toggle" data-size="mini" data-onstyle="success" data-offstyle="danger" data-on="Show" data-off="Hide" data-id="<?php echo e($vehicle_setting->id); ?>" data-action_type="vehicle-settings">
                                                <?php else: ?>
                                                <input type="checkbox" class="is_active" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-size="mini" data-on="Show" data-off="Hide" data-id="<?php echo e($vehicle_setting->id); ?>" data-action_type="vehicle-settings">
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a class="btn btn-primary btn-xs" href="<?php echo e(route('vehicle-settings.edit', $vehicle_setting->id)); ?>">Edit</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="3">No Record Found</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Name</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="pagination">
                                <?php echo e($vehicle_settings->links("pagination::bootstrap-5")); ?>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/encoreskydev-passenger-reporting/htdocs/passenger-reporting.encoreskydev.com/resources/views/dashboard/vehicle_settings/index.blade.php ENDPATH**/ ?>