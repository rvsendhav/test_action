<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper d-flex align-items-center auth px-0">
    <div class="row w-100 mx-0">
        <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
                <div class="brand-logo text-center">
                    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo" />
                </div>
                <h6 class="font-weight-light text-center"><?php echo e(__('messages.admin_dashboard.signin')); ?></h6>

                <form class="pt-3" action="<?php echo e(route('web.login.post')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="email" class="form-control form-control-lg" id="email" name="email" placeholder="<?php echo e(__('messages.admin_dashboard.email_address')); ?>">
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control form-control-lg" id="password" name="password" placeholder="<?php echo e(__('messages.admin_dashboard.password')); ?>">
                    </div>
                    <div class="mt-3 d-grid gap-2">
                        <button class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" type="submit" name="submit" id="submit"><?php echo e(__('messages.admin_dashboard.signin_btn')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/encoreskydev-passenger-reporting/htdocs/passenger-reporting.encoreskydev.com/resources/views/auth/login.blade.php ENDPATH**/ ?>