<!-- partial:partials/_sidebar.html -->
<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item <?php echo e(Request::segment(1) == 'dashboard' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('web.dashboard.view')); ?>">
                <i class="icon-grid menu-icon"></i>
                <span class="menu-title"><?php echo e(__('messages.admin_dashboard.dashboard')); ?></span>
            </a>
        </li>

        <?php if(isset($auth_user) && $auth_user && $auth_user->user_type == 'Admin'): ?>
        <li class="nav-item <?php echo e(Request::segment(1) == 'users' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                <i class="mdi mdi-account-multiple-outline menu-icon"></i>
                <span class="menu-title"><?php echo e(__('messages.admin_dashboard.users')); ?></span>
            </a>
        </li>
        <?php endif; ?>

        <li class="nav-item <?php echo e(Request::segment(1) == 'vehicle-settings' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('vehicle-settings.index')); ?>">
                <i class="mdi mdi-receipt menu-icon menu-icon"></i>
                <span class="menu-title"><?php echo e("Vehicles"); ?></span>
            </a>
        </li>

        <li class="nav-item <?php echo e(Request::segment(1) == 'vehicle-stops' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('vehicle-stops.index')); ?>">
                <i class="mdi mdi-receipt menu-icon menu-icon"></i>
                <span class="menu-title"><?php echo e("Stops"); ?></span>
            </a>
        </li>

        <li class="nav-item <?php echo e(Request::segment(1) == 'passenger-logs' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('passenger-logs.index')); ?>">
                <i class="mdi mdi-receipt menu-icon menu-icon"></i>
                <span class="menu-title"><?php echo e("Passenger Logs"); ?></span>
            </a>
        </li>

        <li class="nav-item <?php echo e(Request::segment(1) == 'reporting' ? 'active' : ''); ?>">
            <a class="nav-link" data-bs-toggle="collapse" href="#reports-statistics" aria-expanded="false" aria-controls="reports-statistics">
                <i class="mdi mdi-account-circle menu-icon"></i>
                <span class="menu-title"><?php echo e("Transit Flow Analytics"); ?></span>
                <i class="menu-arrow"></i>
            </a>

            <div class="collapse <?php echo e(Request::segment(1) == 'reporting' ? 'show' : ''); ?>" id="reports-statistics">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Request::segment(2) == 'vehicle-monthly-ins-outs' ? 'active' : ''); ?>" href="<?php echo e(route('web.vehicle.monthly.ins.outs.view')); ?>">
                            <?php echo e("Monthly View"); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Request::segment(2) == 'stop-total-ins-outs' ? 'active' : ''); ?>" href="<?php echo e(route('web.stop.total.ins.outs.view')); ?>">
                            <?php echo e("Stop Summary"); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Request::segment(2) == 'stop-monthly-daily-ins-outs' ? 'active' : ''); ?>" href="<?php echo e(route('web.stop.monthly.daily.ins.outs.view')); ?>">
                            <?php echo e("Daily by Stop"); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Request::segment(2) == 'month-weekday-ins-outs' ? 'active' : ''); ?>" href="<?php echo e(route('web.month.weekday.ins.outs.view')); ?>">
                            <?php echo e("Weekday Stats"); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Request::segment(2) == 'day-total-ins-outs' ? 'active' : ''); ?>" href="<?php echo e(route('web.day.total.ins.outs.view')); ?>">
                            <?php echo e("Daily Stops"); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Request::segment(2) == 'day-hourly-ins-outs' ? 'active' : ''); ?>" href="<?php echo e(route('web.day.hourly.ins.outs.view')); ?>">
                            <?php echo e("Hourly View"); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Request::segment(2) == 'stop-six-month-ins-outs' ? 'active' : ''); ?>" href="<?php echo e(route('web.stop.six.month.ins.outs.view')); ?>">
                            <?php echo e("6-Month Trend"); ?>

                        </a>
                    </li>
                </ul>
            </div>
        </li>

        <li class="nav-item <?php echo e(Request::segment(1) == 'profile' ? 'active' : ''); ?> <?php echo e(Request::segment(1) == 'change-password' ? 'active' : ''); ?>">
            <a class="nav-link" data-bs-toggle="collapse" href="#account" aria-expanded="false" aria-controls="account">
                <i class="mdi mdi-account-circle menu-icon"></i>
                <span class="menu-title"><?php echo e(__('messages.admin_dashboard.account')); ?></span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse <?php echo e(Request::segment(1) == 'profile' ? 'show' : ''); ?> <?php echo e(Request::segment(1) == 'change-password' ? 'show' : ''); ?>" id="account">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link <?php echo e(Request::segment(1) == 'profile' ? 'active' : ''); ?>" href="<?php echo e(route('web.dashboard.profile')); ?>"><?php echo e(__('messages.admin_dashboard.profile')); ?></a></li>
                    <li class="nav-item"> <a class="nav-link <?php echo e(Request::segment(1) == 'change-password' ? 'active' : ''); ?>" href="<?php echo e(route('web.dashboard.change-password')); ?>"><?php echo e(__('messages.admin_dashboard.change_password')); ?></a></li>
                </ul>
            </div>
        </li>
    </ul>
</nav>
<!-- partial --><?php /**PATH /home/encoreskydev-passenger-reporting/htdocs/passenger-reporting.encoreskydev.com/resources/views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>