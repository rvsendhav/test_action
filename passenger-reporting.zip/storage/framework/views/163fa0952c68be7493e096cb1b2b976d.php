<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <h4 class="card-title">
                                Users (<?php echo e($total_users); ?>)
                            </h4>
                        </div>
                        <div class="col-lg-4">
                            <form class="forms-sample" action="<?php echo e(route('users.index')); ?>" method="GET">
                                <div class="form-group">
                                    <div class="input-group d-flex align-items-center">
                                        <input type="text" class="form-control form-control-sm" value="<?php echo e($search ?? ''); ?>" placeholder="Search" aria-label="Search" name="search">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary btn-md ms-2" type="submit">Search</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-2">
                            <a class="btn btn-primary pull-right" href="<?php echo e(route('users.create')); ?>">Add New</a>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <hr/>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(isset($users) && sizeof($users)): ?>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php if( $user->image ): ?>
                                                    <img src="<?php echo e(url(Storage::url($user->image))); ?>" alt="<?php echo e($user->name); ?>" width="100" height="100" />
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('assets/images/faces/avatar.webp')); ?>" alt="<?php echo e($user->name); ?>" width="100" height="100" />
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td>
                                                <?php if( $user->user_type !== 'Admin' && $user->id !== $auth_user->id ): ?>
                                                <?php if($user->is_active): ?>
                                                <input type="checkbox" class="is_active" checked data-toggle="toggle" data-size="mini" data-onstyle="success" data-offstyle="danger" data-on="Active" data-off="Inactive" data-id="<?php echo e($user->id); ?>" data-action_type="users">
                                                <?php else: ?>
                                                <input type="checkbox" class="is_active" data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-size="mini" data-on="Active" data-off="Inactive" data-id="<?php echo e($user->id); ?>" data-action_type="users">
                                                <?php endif; ?>
                                                <?php else: ?>
                                                <?php if($user->is_active): ?>
                                                <label class="badge badge-success">Active</label>
                                                <?php else: ?>
                                                <label class="badge badge-warning">Inactive</label>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if( $user->id !== $auth_user->id ): ?>
                                                <a class="btn btn-primary btn-xs" href="<?php echo e(route('users.edit', $user->id)); ?>">Edit</a>
                                                <?php endif; ?>
                                                
                                                <?php if( $user->id !== $auth_user->id ): ?>
                                                <a class="btn btn-primary btn-xs" href="<?php echo e(route('users.reset.password', $user->id)); ?>">Reset Password</a>
                                                <?php endif; ?>

                                                <?php if( $user->id !== $auth_user->id ): ?>
                                                <br/><br/>
                                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" onsubmit="return confirmDelete()">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-xs">Delete</button>
                                                </form>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="6">No Record Found</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Image</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="pagination">
                                <?php echo e($users->links("pagination::bootstrap-5")); ?>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
<!-- content-wrapper ends -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/encoreskydev-passenger-reporting/htdocs/passenger-reporting.encoreskydev.com/resources/views/dashboard/user/index.blade.php ENDPATH**/ ?>