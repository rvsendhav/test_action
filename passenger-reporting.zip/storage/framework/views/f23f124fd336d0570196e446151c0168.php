<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Terminal Admin</title>
  <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo.png')); ?>" type="image/x-icon">
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/feather/feather.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/ti-icons/css/themify-icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/css/vendor.bundle.base.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/font-awesome/css/font-awesome.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/mdi/css/materialdesignicons.min.css')); ?>">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
  <!-- endinject -->
</head>

<body>
  <div class="container-scroller">
    <div class="row notification-container end-0 top-0">
        <div id="notification-container" class="col-lg-12 end-0 top-0">
            
        </div>
    </div>
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <?php echo $__env->yieldContent('content'); ?>
      
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?php echo e(asset('assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="<?php echo e(asset('assets/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/template.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/settings.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/todolist.js')); ?>"></script>
  <!-- endinject -->
  <?php if(session('success')): ?>
    <script>
        $(document).ready(function(){
            // Create a success message element
            var successMessage = $('<div class="alert alert-success end-0 top-0">').text('<?php echo e(session('success')); ?>');

            // Append the success message to the container
            $('#notification-container').append(successMessage);

            // Automatically remove the success message after 3 seconds
            setTimeout(function(){
                successMessage.remove();
            }, 3000);
        });
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <script>
        $(document).ready(function(){
            // Create an error message element
            var errorMessage = $('<div class="alert alert-danger end-0 top-0">').text('<?php echo e(session('error')); ?>');

            // Append the error message to the container
            $('#notification-container').append(errorMessage);

            // Automatically remove the error message after 3 seconds
            setTimeout(function(){
                errorMessage.remove();
            }, 3000);
        });
    </script>
<?php endif; ?>
</body>

</html><?php /**PATH /home/encoreskydev-passenger-reporting/htdocs/passenger-reporting.encoreskydev.com/resources/views/auth/layouts/app.blade.php ENDPATH**/ ?>